"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { getCharacterById } from "@/lib/game-data";
import { getLeaderboard, LeaderboardEntry, getPlayer, PlayerData } from "@/lib/storage";
import { soundManager } from "@/lib/sounds";
import { cn } from "@/lib/utils";

export default function LeaderboardPage() {
  const router = useRouter();
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [player, setPlayer] = useState<PlayerData | null>(null);

  useEffect(() => {
    const savedPlayer = getPlayer();
    if (!savedPlayer) {
      router.push("/");
      return;
    }
    setPlayer(savedPlayer);
    setEntries(getLeaderboard());
  }, [router]);

  if (!player) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-secondary to-background">
        <div className="animate-pulse text-2xl text-foreground">Yukleniyor...</div>
      </div>
    );
  }

  const playerRank = entries.findIndex(e => e.name === player.name && e.character === player.character) + 1;

  return (
    <main className="min-h-screen flex flex-col bg-gradient-to-br from-background via-secondary to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-background/80 border-b border-border/30">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              soundManager.play("click");
              router.push("/game");
            }}
            className="text-muted-foreground"
          >
            ← Geri
          </Button>
          <h1 className="font-semibold text-foreground flex items-center gap-2">
            <span>🏆</span> Liderlik Tablosu
          </h1>
          <div className="w-16" />
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 p-4 py-6">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Player Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-primary/20 to-accent/20 border border-primary/30 rounded-2xl p-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <span className="text-4xl">{getCharacterById(player.character)?.emoji}</span>
                  {playerRank > 0 && playerRank <= 3 && (
                    <span className="absolute -top-1 -right-1 text-lg">
                      {playerRank === 1 ? "🥇" : playerRank === 2 ? "🥈" : "🥉"}
                    </span>
                  )}
                </div>
                <div>
                  <p className="font-semibold text-foreground">{player.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {playerRank > 0 ? `#${playerRank} Sira` : "Henuz listede degil"}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-accent">{player.xp}</p>
                <p className="text-xs text-muted-foreground">XP</p>
              </div>
            </div>
          </motion.div>

          {/* Top 3 Podium */}
          {entries.length >= 3 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="flex items-end justify-center gap-2 py-4"
            >
              {/* 2nd Place */}
              <div className="flex flex-col items-center">
                <span className="text-4xl mb-2">{getCharacterById(entries[1].character)?.emoji}</span>
                <div className="bg-gray-400/20 rounded-t-xl w-24 h-20 flex flex-col items-center justify-center">
                  <span className="text-2xl">🥈</span>
                  <p className="text-xs text-muted-foreground truncate w-full text-center px-1">{entries[1].name}</p>
                  <p className="text-sm font-bold text-foreground">{entries[1].score}</p>
                </div>
              </div>
              
              {/* 1st Place */}
              <div className="flex flex-col items-center">
                <span className="text-5xl mb-2">{getCharacterById(entries[0].character)?.emoji}</span>
                <div className="bg-yellow-500/20 rounded-t-xl w-28 h-28 flex flex-col items-center justify-center">
                  <span className="text-3xl">🥇</span>
                  <p className="text-sm text-foreground truncate w-full text-center px-1 font-medium">{entries[0].name}</p>
                  <p className="text-lg font-bold text-accent">{entries[0].score}</p>
                </div>
              </div>
              
              {/* 3rd Place */}
              <div className="flex flex-col items-center">
                <span className="text-4xl mb-2">{getCharacterById(entries[2].character)?.emoji}</span>
                <div className="bg-orange-600/20 rounded-t-xl w-24 h-16 flex flex-col items-center justify-center">
                  <span className="text-xl">🥉</span>
                  <p className="text-xs text-muted-foreground truncate w-full text-center px-1">{entries[2].name}</p>
                  <p className="text-sm font-bold text-foreground">{entries[2].score}</p>
                </div>
              </div>
            </motion.div>
          )}

          {/* Leaderboard List */}
          <div className="space-y-2">
            {entries.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12"
              >
                <span className="text-6xl block mb-4">🏆</span>
                <p className="text-muted-foreground">Henuz skor yok!</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Oyun oynayarak liderlik tablosuna gir!
                </p>
              </motion.div>
            ) : (
              entries.slice(3).map((entry, index) => {
                const rank = index + 4;
                const character = getCharacterById(entry.character);
                const isCurrentPlayer = entry.name === player.name && entry.character === player.character;
                
                return (
                  <motion.div
                    key={`${entry.name}-${entry.date}-${index}`}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className={cn(
                      "flex items-center gap-4 p-4 rounded-xl border transition-all",
                      isCurrentPlayer
                        ? "bg-primary/10 border-primary/30"
                        : "bg-card/50 border-border/30"
                    )}
                  >
                    <div className="w-8 text-center">
                      <span className={cn(
                        "font-bold",
                        rank <= 10 ? "text-foreground" : "text-muted-foreground"
                      )}>
                        {rank}
                      </span>
                    </div>
                    
                    <span className="text-3xl">{character?.emoji || "👤"}</span>
                    
                    <div className="flex-1 min-w-0">
                      <p className={cn(
                        "font-medium truncate",
                        isCurrentPlayer ? "text-primary" : "text-foreground"
                      )}>
                        {entry.name}
                        {isCurrentPlayer && <span className="ml-2 text-xs">(Sen)</span>}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Seviye {entry.level}
                      </p>
                    </div>
                    
                    <div className="text-right">
                      <p className="font-bold text-accent">{entry.score}</p>
                      <p className="text-xs text-muted-foreground">XP</p>
                    </div>
                  </motion.div>
                );
              })
            )}
          </div>

          {/* Empty State for few entries */}
          {entries.length > 0 && entries.length < 5 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-center py-8 border-t border-border/30"
            >
              <p className="text-sm text-muted-foreground">
                Daha fazla oyuncu bekleniyor...
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Arkadaslarini davet et ve yarismayi kiziştir!
              </p>
            </motion.div>
          )}
        </div>
      </div>
    </main>
  );
}
