"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { characters, Character } from "@/lib/game-data";
import { createPlayer, resetGame } from "@/lib/storage";
import { soundManager } from "@/lib/sounds";
import { cn } from "@/lib/utils";
import { triggerConfetti } from "@/components/confetti";

export default function CharacterPage() {
  const router = useRouter();
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const [playerName, setPlayerName] = useState("");
  const [step, setStep] = useState<"name" | "character">("name");
  const [error, setError] = useState("");

  const handleNameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (playerName.trim().length < 2) {
      setError("Isim en az 2 karakter olmali");
      return;
    }
    if (playerName.trim().length > 15) {
      setError("Isim en fazla 15 karakter olmali");
      return;
    }
    soundManager.play("click");
    setError("");
    setStep("character");
  };

  const handleSelectCharacter = (character: Character) => {
    soundManager.play("click");
    setSelectedCharacter(character);
  };

  const handleStart = () => {
    if (!selectedCharacter) return;
    
    soundManager.play("levelup");
    triggerConfetti("badge");
    
    resetGame();
    createPlayer(playerName.trim(), selectedCharacter.id);
    
    setTimeout(() => {
      router.push("/game");
    }, 500);
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-background via-secondary to-background overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {characters.map((char, i) => (
          <motion.div
            key={char.id}
            className="absolute text-6xl opacity-10"
            style={{
              left: `${20 + i * 20}%`,
              top: `${30 + (i % 2) * 40}%`,
            }}
            animate={{
              y: [0, -20, 0],
              rotate: [0, 10, -10, 0],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              delay: i * 0.5,
            }}
          >
            {char.emoji}
          </motion.div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {step === "name" ? (
          <motion.div
            key="name"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="relative z-10 w-full max-w-md space-y-8"
          >
            <div className="text-center space-y-4">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-7xl"
              >
                👋
              </motion.div>
              <h1 className="text-3xl font-bold text-foreground">Hosgeldin!</h1>
              <p className="text-muted-foreground">
                Once sana nasil hitap edelim?
              </p>
            </div>

            <form onSubmit={handleNameSubmit} className="space-y-4">
              <div className="space-y-2">
                <input
                  type="text"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  placeholder="Adini yaz..."
                  className={cn(
                    "w-full px-4 py-4 rounded-xl text-lg text-center",
                    "bg-card/50 border-2 border-border/30",
                    "focus:outline-none focus:border-primary",
                    "placeholder:text-muted-foreground/50",
                    "text-foreground"
                  )}
                  autoFocus
                />
                {error && (
                  <motion.p
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-sm text-destructive text-center"
                  >
                    {error}
                  </motion.p>
                )}
              </div>
              
              <Button
                type="submit"
                size="lg"
                className="w-full h-14 text-lg font-semibold"
              >
                Devam Et
              </Button>
            </form>
          </motion.div>
        ) : (
          <motion.div
            key="character"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="relative z-10 w-full max-w-2xl space-y-6"
          >
            <div className="text-center space-y-2">
              <h1 className="text-3xl font-bold text-foreground">
                Merhaba, <span className="text-primary">{playerName}</span>!
              </h1>
              <p className="text-muted-foreground">
                Macera arkadasini sec
              </p>
            </div>

            {/* Character Grid */}
            <div className="grid grid-cols-2 gap-4">
              {characters.map((character, index) => (
                <motion.button
                  key={character.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleSelectCharacter(character)}
                  className={cn(
                    "relative p-6 rounded-2xl text-left transition-all",
                    "border-2",
                    selectedCharacter?.id === character.id
                      ? `bg-gradient-to-br ${character.color} border-white/30 shadow-lg`
                      : "bg-card/50 border-border/30 hover:border-primary/50"
                  )}
                >
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <span className="text-5xl">{character.emoji}</span>
                      <div>
                        <h3 className={cn(
                          "text-lg font-bold",
                          selectedCharacter?.id === character.id ? "text-white" : "text-foreground"
                        )}>
                          {character.name}
                        </h3>
                        <p className={cn(
                          "text-sm",
                          selectedCharacter?.id === character.id ? "text-white/70" : "text-muted-foreground"
                        )}>
                          {character.description}
                        </p>
                      </div>
                    </div>
                    
                    {/* Power Info */}
                    <div className={cn(
                      "p-3 rounded-xl",
                      selectedCharacter?.id === character.id ? "bg-white/10" : "bg-secondary/50"
                    )}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm">⚡</span>
                        <span className={cn(
                          "text-sm font-semibold",
                          selectedCharacter?.id === character.id ? "text-white" : "text-foreground"
                        )}>
                          {character.power}
                        </span>
                      </div>
                      <p className={cn(
                        "text-xs",
                        selectedCharacter?.id === character.id ? "text-white/60" : "text-muted-foreground"
                      )}>
                        {character.powerDescription}
                      </p>
                    </div>
                  </div>

                  {selectedCharacter?.id === character.id && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute top-3 right-3 w-6 h-6 rounded-full bg-white flex items-center justify-center"
                    >
                      <span className="text-primary text-sm">✓</span>
                    </motion.div>
                  )}
                </motion.button>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                size="lg"
                onClick={() => {
                  soundManager.play("click");
                  setStep("name");
                }}
                className="flex-1"
              >
                Geri
              </Button>
              <Button
                size="lg"
                onClick={handleStart}
                disabled={!selectedCharacter}
                className="flex-1 h-14"
              >
                Maceraya Basla! 🚀
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
