"use client";

import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { getWorldById, World, Topic, getCharacterById, Character } from "@/lib/game-data";
import { getPlayer, getTopicProgress, calculateWorldCompletion, PlayerData } from "@/lib/storage";
import { soundManager } from "@/lib/sounds";
import { cn } from "@/lib/utils";

export default function WorldDetailPage() {
  const router = useRouter();
  const params = useParams();
  const worldId = params.worldId as string;

  const [world, setWorld] = useState<World | null>(null);
  const [player, setPlayer] = useState<PlayerData | null>(null);
  const [character, setCharacter] = useState<Character | null>(null);

  useEffect(() => {
    const savedPlayer = getPlayer();
    if (!savedPlayer) {
      router.push("/");
      return;
    }
    setPlayer(savedPlayer);
    setCharacter(getCharacterById(savedPlayer.character) || null);

    const foundWorld = getWorldById(worldId);
    if (!foundWorld) {
      router.push("/game");
      return;
    }
    setWorld(foundWorld);
  }, [worldId, router]);

  if (!world || !player || !character) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-secondary to-background">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-center"
        >
          <div className="text-5xl mb-4 animate-bounce">{world?.icon || "🧮"}</div>
          <div className="text-xl text-foreground">Yukleniyor...</div>
        </motion.div>
      </div>
    );
  }

  const completion = calculateWorldCompletion(world.id, world.topics.length);
  const isBossUnlocked = completion >= 80;

  return (
    <main className="min-h-screen flex flex-col bg-gradient-to-br from-background via-secondary to-background">
      {/* Header */}
      <header className={cn(
        "sticky top-0 z-50 backdrop-blur-md border-b border-white/10",
        `bg-gradient-to-r ${world.color}`
      )}>
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                soundManager.play("click");
                router.push("/game");
              }}
              className="text-white/80 hover:text-white hover:bg-white/10"
            >
              ← Geri
            </Button>
            <div className="text-center">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{world.icon}</span>
                <h1 className="text-xl font-bold text-white">{world.name}</h1>
              </div>
              <p className="text-xs text-white/60">{world.grade}. Sinif</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-bold text-white">%{completion}</p>
              <p className="text-xs text-white/60">tamamlandi</p>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-3 h-2 rounded-full bg-black/30 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${completion}%` }}
              transition={{ duration: 0.5 }}
              className="h-full rounded-full bg-white/80"
            />
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 p-4 py-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* World Description */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <p className="text-muted-foreground">{world.description}</p>
          </motion.div>

          {/* Topics Grid */}
          <div className="grid sm:grid-cols-2 gap-4">
            {world.topics.map((topic, index) => (
              <TopicCard
                key={topic.id}
                topic={topic}
                world={world}
                index={index}
              />
            ))}
          </div>

          {/* Boss Battle */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className={cn(
              "relative overflow-hidden rounded-2xl p-6 border",
              isBossUnlocked
                ? "bg-gradient-to-br from-red-600 to-orange-600 border-white/20"
                : "bg-card/30 border-border/30"
            )}
          >
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-4 right-4 text-[120px]">{world.bossEmoji}</div>
            </div>
            
            <div className="relative z-10 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <span className={cn(
                  "text-6xl",
                  !isBossUnlocked && "grayscale opacity-50"
                )}>
                  {world.bossEmoji}
                </span>
                <div>
                  <h3 className={cn(
                    "text-xl font-bold",
                    isBossUnlocked ? "text-white" : "text-muted-foreground"
                  )}>
                    {world.bossName}
                  </h3>
                  <p className={cn(
                    "text-sm",
                    isBossUnlocked ? "text-white/70" : "text-muted-foreground"
                  )}>
                    {isBossUnlocked 
                      ? "Boss savasi acildi! 15 soru, 5 can." 
                      : `%80 ilerleme gerekli (su an: %${completion})`
                    }
                  </p>
                </div>
              </div>
              
              <Button
                disabled={!isBossUnlocked}
                onClick={() => {
                  soundManager.play("click");
                  router.push(`/game/play/${world.topics[0].id}?mode=boss&world=${world.id}`);
                }}
                className={cn(
                  isBossUnlocked
                    ? "bg-white/20 hover:bg-white/30 text-white border border-white/30"
                    : ""
                )}
              >
                {isBossUnlocked ? "⚔️ Savasa Gir" : "🔒 Kilitli"}
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </main>
  );
}

interface TopicCardProps {
  topic: Topic;
  world: World;
  index: number;
}

function TopicCard({ topic, world, index }: TopicCardProps) {
  const router = useRouter();
  const progress = getTopicProgress(world.id, topic.id);
  const isCompleted = progress.completed >= 10;
  const accuracy = progress.completed > 0 
    ? Math.round((progress.correct / progress.completed) * 100) 
    : 0;

  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => {
        soundManager.play("click");
        router.push(`/game/play/${topic.id}?mode=classic`);
      }}
      className={cn(
        "relative p-5 rounded-xl text-left transition-all border",
        isCompleted
          ? "bg-success/10 border-success/30"
          : "bg-card/50 border-border/30 hover:border-primary/50"
      )}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{topic.icon}</span>
          <div>
            <h3 className="font-semibold text-foreground">{topic.name}</h3>
            <p className="text-xs text-muted-foreground">{topic.description}</p>
          </div>
        </div>
        {isCompleted && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="text-xl"
          >
            ⭐
          </motion.span>
        )}
      </div>

      {/* Difficulty Stars */}
      <div className="flex items-center gap-1 mb-3">
        <span className="text-xs text-muted-foreground mr-1">Zorluk:</span>
        {[1, 2, 3].map((i) => (
          <span
            key={i}
            className={cn(
              "text-xs",
              i <= topic.difficulty ? "text-yellow-500" : "text-muted-foreground/30"
            )}
          >
            ★
          </span>
        ))}
      </div>

      {/* Progress */}
      {progress.completed > 0 && (
        <div className="space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">
              {progress.completed} soru cozuldu
            </span>
            <span className={cn(
              "font-medium",
              accuracy >= 70 ? "text-success" : accuracy >= 50 ? "text-accent" : "text-muted-foreground"
            )}>
              %{accuracy} basari
            </span>
          </div>
          <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
            <div
              className={cn(
                "h-full rounded-full transition-all",
                isCompleted ? "bg-success" : "bg-primary"
              )}
              style={{ width: `${Math.min((progress.completed / 10) * 100, 100)}%` }}
            />
          </div>
        </div>
      )}

      {progress.completed === 0 && (
        <p className="text-xs text-muted-foreground">Henuz baslanmadi</p>
      )}

      {/* Best Streak */}
      {progress.bestStreak > 0 && (
        <div className="mt-2 flex items-center gap-1 text-xs text-accent">
          <span>🔥</span>
          <span>En iyi seri: {progress.bestStreak}</span>
        </div>
      )}
    </motion.button>
  );
}
