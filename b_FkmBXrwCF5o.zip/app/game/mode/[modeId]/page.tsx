"use client";

import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { worlds, getGameModeById, GameMode, Topic, getCharacterById } from "@/lib/game-data";
import { getPlayer } from "@/lib/storage";
import { soundManager } from "@/lib/sounds";
import { cn } from "@/lib/utils";

export default function GameModeSelectPage() {
  const router = useRouter();
  const params = useParams();
  const modeId = params.modeId as string;

  const [mode, setMode] = useState<GameMode | null>(null);
  const [selectedWorld, setSelectedWorld] = useState<string | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);

  useEffect(() => {
    const player = getPlayer();
    if (!player) {
      router.push("/");
      return;
    }

    const foundMode = getGameModeById(modeId);
    if (!foundMode) {
      router.push("/game");
      return;
    }
    setMode(foundMode);
  }, [modeId, router]);

  const handleStartGame = () => {
    if (!selectedTopic || !mode) return;
    soundManager.play("click");
    router.push(`/game/play/${selectedTopic.id}?mode=${mode.id}`);
  };

  if (!mode) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-secondary to-background">
        <div className="text-2xl text-foreground animate-pulse">Yukleniyor...</div>
      </div>
    );
  }

  return (
    <main className="min-h-screen flex flex-col bg-gradient-to-br from-background via-secondary to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-background/80 border-b border-border/30">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              soundManager.play("click");
              router.push("/game");
            }}
            className="text-muted-foreground"
          >
            ← Geri
          </Button>
          <h1 className="font-semibold text-foreground flex items-center gap-2">
            <span className="text-xl">{mode.icon}</span>
            {mode.name}
          </h1>
          <div className="w-16" />
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 p-4 py-6">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Mode Info */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={cn(
              "p-6 rounded-2xl text-center border border-white/10",
              `bg-gradient-to-br ${mode.color}`
            )}
          >
            <span className="text-5xl block mb-3">{mode.icon}</span>
            <h2 className="text-xl font-bold text-white">{mode.name}</h2>
            <p className="text-white/80 mt-1">{mode.description}</p>
            <div className="flex items-center justify-center gap-4 mt-4 text-sm text-white/70">
              {mode.timeLimit && (
                <span className="flex items-center gap-1">
                  <span>⏱️</span> {mode.timeLimit}s
                </span>
              )}
              {mode.livesCount && (
                <span className="flex items-center gap-1">
                  <span>❤️</span> {mode.livesCount} Can
                </span>
              )}
              <span className="flex items-center gap-1">
                <span>✨</span> {mode.pointsMultiplier}x Puan
              </span>
            </div>
          </motion.div>

          {/* World Selection */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-foreground">Dunya Sec</h3>
            <div className="grid grid-cols-2 gap-3">
              {worlds.map((world) => (
                <motion.button
                  key={world.id}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    soundManager.play("click");
                    setSelectedWorld(world.id);
                    setSelectedTopic(null);
                  }}
                  className={cn(
                    "p-4 rounded-xl text-left transition-all border",
                    selectedWorld === world.id
                      ? `bg-gradient-to-br ${world.color} border-white/30`
                      : "bg-card/50 border-border/30 hover:border-primary/50"
                  )}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-3xl">{world.icon}</span>
                    <div>
                      <p className={cn(
                        "font-semibold",
                        selectedWorld === world.id ? "text-white" : "text-foreground"
                      )}>
                        {world.name}
                      </p>
                      <p className={cn(
                        "text-xs",
                        selectedWorld === world.id ? "text-white/70" : "text-muted-foreground"
                      )}>
                        {world.grade}. Sinif
                      </p>
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Topic Selection */}
          <AnimatePresence mode="wait">
            {selectedWorld && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-3"
              >
                <h3 className="text-lg font-semibold text-foreground">Konu Sec</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {worlds
                    .find((w) => w.id === selectedWorld)
                    ?.topics.map((topic) => (
                      <motion.button
                        key={topic.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => {
                          soundManager.play("click");
                          setSelectedTopic(topic);
                        }}
                        className={cn(
                          "p-3 rounded-xl text-left transition-all border",
                          selectedTopic?.id === topic.id
                            ? "bg-primary border-primary text-primary-foreground"
                            : "bg-card/50 border-border/30 hover:border-primary/50"
                        )}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{topic.icon}</span>
                          <div>
                            <p className={cn(
                              "text-sm font-medium",
                              selectedTopic?.id === topic.id ? "text-primary-foreground" : "text-foreground"
                            )}>
                              {topic.name}
                            </p>
                            <div className="flex items-center gap-1 mt-0.5">
                              {[1, 2, 3].map((i) => (
                                <span
                                  key={i}
                                  className={cn(
                                    "text-xs",
                                    i <= topic.difficulty ? "text-yellow-500" : "text-muted-foreground/30"
                                  )}
                                >
                                  ★
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </motion.button>
                    ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Start Button */}
      <AnimatePresence>
        {selectedTopic && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="sticky bottom-0 z-40 bg-background/90 backdrop-blur-md border-t border-border/30 p-4"
          >
            <div className="max-w-2xl mx-auto">
              <Button
                size="lg"
                onClick={handleStartGame}
                className="w-full h-14 text-lg font-semibold bg-gradient-to-r from-primary to-primary/80 shadow-lg"
              >
                {mode.icon} Oyunu Baslat - {selectedTopic.name}
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
