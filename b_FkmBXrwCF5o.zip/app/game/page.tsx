"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { worlds, getCharacterById, Character, gameModes, getLevelFromXP, getXPForNextLevel, dailyChallenges } from "@/lib/game-data";
import { getPlayer, calculateWorldCompletion, PlayerData, getDailyData, claimDailyReward } from "@/lib/storage";
import { soundManager } from "@/lib/sounds";
import { cn } from "@/lib/utils";
import { triggerConfetti } from "@/components/confetti";

export default function GamePage() {
  const router = useRouter();
  const [player, setPlayer] = useState<PlayerData | null>(null);
  const [character, setCharacter] = useState<Character | null>(null);
  const [activeTab, setActiveTab] = useState<"worlds" | "daily" | "shop">("worlds");

  useEffect(() => {
    const savedPlayer = getPlayer();
    if (!savedPlayer) {
      router.push("/");
      return;
    }
    setPlayer(savedPlayer);
    setCharacter(getCharacterById(savedPlayer.character) || null);
  }, [router]);

  if (!player || !character) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-secondary to-background">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-2xl text-foreground"
        >
          <div className="text-5xl mb-4 animate-bounce">🧮</div>
          Yukleniyor...
        </motion.div>
      </div>
    );
  }

  const level = getLevelFromXP(player.xp);
  const xpProgress = getXPForNextLevel(player.xp);

  return (
    <main className="min-h-screen flex flex-col bg-gradient-to-br from-background via-secondary to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-background/80 border-b border-border/30">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            {/* Player Info */}
            <Link href="/profile" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
              <div className="relative">
                <div className="text-4xl">{character.emoji}</div>
                <div className="absolute -bottom-1 -right-1 bg-primary text-primary-foreground text-xs font-bold px-1.5 rounded-full">
                  {level}
                </div>
              </div>
              <div className="hidden sm:block">
                <p className="font-semibold text-foreground">{player.name}</p>
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-muted-foreground">XP {player.xp}</span>
                </div>
              </div>
            </Link>

            {/* Currency */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5 bg-yellow-500/20 px-3 py-1.5 rounded-full">
                <span className="text-lg">💎</span>
                <span className="font-bold text-foreground">{player.gems}</span>
              </div>
              <Link href="/leaderboard">
                <Button variant="ghost" size="sm" className="text-muted-foreground">
                  🏆
                </Button>
              </Link>
              <Link href="/settings">
                <Button variant="ghost" size="sm" className="text-muted-foreground">
                  ⚙️
                </Button>
              </Link>
            </div>
          </div>

          {/* XP Progress Bar */}
          <div className="mt-2">
            <div className="h-2 rounded-full bg-secondary overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${xpProgress.progress}%` }}
                transition={{ duration: 0.5 }}
                className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
              />
            </div>
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>Seviye {level}</span>
              <span>{xpProgress.current} / {xpProgress.needed} XP</span>
            </div>
          </div>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="sticky top-[88px] z-40 bg-background/80 backdrop-blur-md border-b border-border/30">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex gap-2 py-2">
            {[
              { id: "worlds", label: "Dunyalar", icon: "🗺️" },
              { id: "daily", label: "Gunluk", icon: "📅" },
              { id: "shop", label: "Market", icon: "🛒" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  soundManager.play("click");
                  setActiveTab(tab.id as typeof activeTab);
                }}
                className={cn(
                  "flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-sm font-medium transition-all",
                  activeTab === tab.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary/50 text-muted-foreground hover:bg-secondary"
                )}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-4 py-6">
        <div className="max-w-4xl mx-auto">
          {activeTab === "worlds" && <WorldsTab />}
          {activeTab === "daily" && <DailyTab />}
          {activeTab === "shop" && <ShopTab gems={player.gems} />}
        </div>
      </div>

      {/* Bottom Navigation - Game Modes */}
      <div className="sticky bottom-0 z-40 bg-background/90 backdrop-blur-md border-t border-border/30 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-4 gap-2">
            {gameModes.map((mode) => (
              <Link
                key={mode.id}
                href={`/game/mode/${mode.id}`}
                className={cn(
                  "flex flex-col items-center gap-1 p-3 rounded-xl text-center transition-all hover:scale-105",
                  `bg-gradient-to-br ${mode.color}`,
                  "border border-white/10"
                )}
                onClick={() => soundManager.play("click")}
              >
                <span className="text-2xl">{mode.icon}</span>
                <span className="text-xs font-medium text-white">{mode.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}

function WorldsTab() {
  const router = useRouter();

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground">Dunya Haritasi</h2>
        <p className="text-muted-foreground">Bir dunya secerek maceraya basla!</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {worlds.map((world, index) => {
          const completion = calculateWorldCompletion(world.id, world.topics.length);
          return (
            <motion.button
              key={world.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                soundManager.play("click");
                router.push(`/game/world/${world.id}`);
              }}
              className={cn(
                "relative overflow-hidden rounded-2xl p-6 text-left transition-all",
                "bg-gradient-to-br",
                world.color,
                "border border-white/10 shadow-lg"
              )}
            >
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-4 right-4 text-9xl">{world.icon}</div>
              </div>

              <div className="relative z-10 space-y-3">
                <div className="flex items-center gap-3">
                  <span className="text-5xl">{world.icon}</span>
                  <div>
                    <h3 className="text-xl font-bold text-white">{world.name}</h3>
                    <p className="text-sm text-white/70">{world.grade}. Sinif</p>
                  </div>
                </div>

                <p className="text-sm text-white/80">{world.description}</p>

                <div className="flex items-center gap-2 text-sm text-white/60">
                  <span className="text-lg">{world.bossEmoji}</span>
                  <span>Boss: {world.bossName}</span>
                </div>

                {/* Progress */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-white/70">
                    <span>{world.topics.length} Konu</span>
                    <span>%{completion}</span>
                  </div>
                  <div className="h-2 rounded-full bg-black/30 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${completion}%` }}
                      transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
                      className="h-full rounded-full bg-white/80"
                    />
                  </div>
                </div>

                {completion === 100 && (
                  <div className="flex items-center gap-2 text-sm text-yellow-300 font-medium">
                    <span>Tamamlandi</span>
                    <span>⭐</span>
                  </div>
                )}
              </div>
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );
}

function DailyTab() {
  const [daily, setDaily] = useState(getDailyData());

  const handleClaimReward = (challengeId: string) => {
    const reward = claimDailyReward(challengeId);
    if (reward > 0) {
      soundManager.play("badge");
      triggerConfetti("success");
      setDaily(getDailyData());
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="text-center">
        <h2 className="text-2xl font-bold text-foreground">Gunluk Gorevler</h2>
        <p className="text-muted-foreground">Her gun oduller kazan!</p>
      </div>

      {/* Daily Stats */}
      {daily && (
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-card/50 border border-border/30 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-foreground">{daily.questionsAnswered}</div>
            <div className="text-xs text-muted-foreground">Cozulen Soru</div>
          </div>
          <div className="bg-card/50 border border-border/30 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-success">{daily.correctAnswers}</div>
            <div className="text-xs text-muted-foreground">Dogru Cevap</div>
          </div>
          <div className="bg-card/50 border border-border/30 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-accent">{daily.bestStreak}</div>
            <div className="text-xs text-muted-foreground">En Iyi Seri</div>
          </div>
        </div>
      )}

      {/* Challenges */}
      <div className="space-y-3">
        {dailyChallenges.map((challenge, index) => {
          const progress = daily?.challenges.find((c) => c.id === challenge.id);
          const current = progress?.current || 0;
          const completed = progress?.completed || false;
          const claimed = progress?.claimedReward || false;
          const percentage = Math.min((current / challenge.requirement) * 100, 100);

          return (
            <motion.div
              key={challenge.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className={cn(
                "bg-card/50 border border-border/30 rounded-xl p-4",
                completed && !claimed && "border-accent/50 bg-accent/10"
              )}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{challenge.icon}</span>
                  <div>
                    <h4 className="font-semibold text-foreground">{challenge.name}</h4>
                    <p className="text-sm text-muted-foreground">{challenge.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  {claimed ? (
                    <span className="text-success text-sm font-medium flex items-center gap-1">
                      <span>✓</span> Alindi
                    </span>
                  ) : completed ? (
                    <Button
                      size="sm"
                      onClick={() => handleClaimReward(challenge.id)}
                      className="bg-accent hover:bg-accent/90"
                    >
                      💎 +{challenge.reward}
                    </Button>
                  ) : (
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <span className="text-lg">💎</span>
                      <span>{challenge.reward}</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="space-y-1">
                <div className="h-2 rounded-full bg-secondary overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    className={cn(
                      "h-full rounded-full",
                      completed ? "bg-success" : "bg-primary"
                    )}
                  />
                </div>
                <div className="text-xs text-muted-foreground text-right">
                  {current} / {challenge.requirement}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}

function ShopTab({ gems }: { gems: number }) {
  const shopItems = [
    { id: "hint-3", name: "3 Ipucu", price: 30, icon: "💡", description: "Zor sorularda yardim al" },
    { id: "hint-10", name: "10 Ipucu", price: 80, icon: "💡", description: "Indirimli ipucu paketi" },
    { id: "power-5", name: "5 Guc Kullanimi", price: 50, icon: "⚡", description: "Karakter gucunu kullan" },
    { id: "xp-boost", name: "XP x2 (1 saat)", price: 100, icon: "🚀", description: "1 saat 2x XP kazan" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="text-center">
        <h2 className="text-2xl font-bold text-foreground">Market</h2>
        <p className="text-muted-foreground">Gem&apos;lerini harca, guc kazan!</p>
        <div className="flex items-center justify-center gap-2 mt-2 text-lg">
          <span>💎</span>
          <span className="font-bold text-accent">{gems} Gem</span>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        {shopItems.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-card/50 border border-border/30 rounded-xl p-4"
          >
            <div className="flex items-start gap-3">
              <span className="text-4xl">{item.icon}</span>
              <div className="flex-1">
                <h4 className="font-semibold text-foreground">{item.name}</h4>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </div>
            </div>
            <Button
              className="w-full mt-3"
              variant={gems >= item.price ? "default" : "outline"}
              disabled={gems < item.price}
              onClick={() => soundManager.play("click")}
            >
              <span className="mr-2">💎</span>
              {item.price}
            </Button>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
