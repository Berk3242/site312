"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useRouter, useParams, useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  getTopicById, 
  Topic, 
  getGameModeById, 
  GameMode, 
  getCharacterById,
  Character,
  getLevelFromXP 
} from "@/lib/game-data";
import { 
  getPlayer, 
  addXP,
  updateStats,
  updateTopicProgress,
  addBadge,
  addToLeaderboard,
  useHint,
  updateSpeedModeHighScore,
  updateSurvivalModeHighScore,
  incrementBossesDefeated,
  PlayerData,
} from "@/lib/storage";
import { generateQuestion, Question } from "@/lib/questions";
import { soundManager } from "@/lib/sounds";
import { cn } from "@/lib/utils";
import { triggerConfetti } from "@/components/confetti";

export default function PlayPage() {
  const router = useRouter();
  const params = useParams();
  const searchParams = useSearchParams();
  const topicId = params.topicId as string;
  const modeId = searchParams.get("mode") || "classic";

  const [topic, setTopic] = useState<Topic | null>(null);
  const [mode, setMode] = useState<GameMode | null>(null);
  const [player, setPlayer] = useState<PlayerData | null>(null);
  const [character, setCharacter] = useState<Character | null>(null);
  
  const [question, setQuestion] = useState<Question | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [eliminatedOption, setEliminatedOption] = useState<number | null>(null);
  
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [lives, setLives] = useState(3);
  const [timeLeft, setTimeLeft] = useState(60);
  const [hintsUsed, setHintsUsed] = useState(0);
  
  const [showResult, setShowResult] = useState(false);
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [newLevel, setNewLevel] = useState(0);
  const [newBadge, setNewBadge] = useState<string | null>(null);
  const [gameOver, setGameOver] = useState(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const loadNewQuestion = useCallback(() => {
    if (!topic) return;
    
    try {
      const newQuestion = generateQuestion(topic.id);
      setQuestion(newQuestion);
      setSelectedAnswer(null);
      setIsCorrect(null);
      setEliminatedOption(null);
    } catch (error) {
      console.error("Soru uretim hatasi:", error);
      router.push("/game");
    }
  }, [topic, router]);

  useEffect(() => {
    const savedPlayer = getPlayer();
    if (!savedPlayer) {
      router.push("/");
      return;
    }
    setPlayer(savedPlayer);
    setCharacter(getCharacterById(savedPlayer.character) || null);

    const foundTopic = getTopicById(topicId);
    const foundMode = getGameModeById(modeId);
    
    if (!foundTopic) {
      router.push("/game");
      return;
    }
    
    setTopic(foundTopic);
    setMode(foundMode || getGameModeById("classic")!);
    
    if (foundMode?.livesCount) {
      setLives(foundMode.livesCount);
    }
    if (foundMode?.timeLimit) {
      setTimeLeft(foundMode.timeLimit);
    }
  }, [topicId, modeId, router]);

  useEffect(() => {
    if (topic && !question) {
      loadNewQuestion();
    }
  }, [topic, question, loadNewQuestion]);

  // Timer for speed mode
  useEffect(() => {
    if (mode?.timeLimit && !gameOver && !showResult) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setGameOver(true);
            setShowResult(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => {
        if (timerRef.current) clearInterval(timerRef.current);
      };
    }
  }, [mode, gameOver, showResult]);

  const finishGame = useCallback(() => {
    if (!mode || !player || !topic) return;

    // XP hesapla
    const baseXP = correctCount * 10;
    const streakBonus = Math.floor(streak / 3) * 5;
    const modeBonus = Math.floor(baseXP * (mode.pointsMultiplier - 1));
    const totalXP = baseXP + streakBonus + modeBonus;

    const xpResult = addXP(totalXP);
    
    if (xpResult.levelUp) {
      setNewLevel(xpResult.newLevel);
      setShowLevelUp(true);
      triggerConfetti("levelUp");
      soundManager.play("levelup");
    }

    // High score guncelle
    if (mode.id === "speed") {
      updateSpeedModeHighScore(questionsAnswered);
    } else if (mode.id === "survival") {
      updateSurvivalModeHighScore(questionsAnswered);
    }

    // Rozetleri kontrol et
    if (correctCount === 1 && !player.badges.includes("baslangic-kahramani")) {
      addBadge("baslangic-kahramani");
      setNewBadge("Baslangic Kahramani");
    }
    if (streak >= 10 && !player.badges.includes("mukemmeliyetci")) {
      addBadge("mukemmeliyetci");
      setNewBadge("Mukemmeliyetci");
    }
    if (streak >= 20 && !player.badges.includes("seri-20")) {
      addBadge("seri-20");
      setNewBadge("Ates Toprak");
    }
    if (mode.id === "speed" && questionsAnswered >= 20 && !player.badges.includes("hizli-dusunur")) {
      addBadge("hizli-dusunur");
      setNewBadge("Hizli Dusunur");
    }
    if (mode.id === "survival" && questionsAnswered >= 20 && !player.badges.includes("hayatta-kalan")) {
      addBadge("hayatta-kalan");
      setNewBadge("Hayatta Kalan");
    }

    // Liderlik tablosuna ekle
    addToLeaderboard({
      name: player.name,
      score: player.xp + totalXP,
      character: player.character,
      level: getLevelFromXP(player.xp + totalXP),
    });

    setShowResult(true);
  }, [mode, player, correctCount, streak, questionsAnswered, topic]);

  const handleAnswer = (answerIndex: number) => {
    if (selectedAnswer !== null || !question || !topic || !mode) return;

    setSelectedAnswer(answerIndex);
    const correct = answerIndex === question.correctIndex;
    setIsCorrect(correct);

    let newStreak = streak;
    let points = 0;

    if (correct) {
      soundManager.play("correct");
      newStreak = streak + 1;
      setStreak(newStreak);
      setCorrectCount((prev) => prev + 1);
      
      // Puan hesapla
      const basePoints = 10;
      const streakMultiplier = Math.min(1 + (newStreak - 1) * 0.1, 2);
      points = Math.floor(basePoints * streakMultiplier * mode.pointsMultiplier);
      setScore((prev) => prev + points);
      
      // Confetti for streaks
      if (newStreak === 5 || newStreak === 10 || newStreak === 15 || newStreak === 20) {
        triggerConfetti("success");
      }
    } else {
      soundManager.play("wrong");
      newStreak = 0;
      setStreak(0);
      
      // Survival modda can kaybet
      if (mode.livesCount) {
        const newLives = lives - 1;
        setLives(newLives);
        if (newLives <= 0) {
          setGameOver(true);
          setTimeout(() => finishGame(), 1000);
          return;
        }
      }
    }

    updateStats(correct, newStreak);
    updateTopicProgress(topic.worldId, topic.id, correct, newStreak);
    setQuestionsAnswered((prev) => prev + 1);

    // Klasik modda 10 soru sonrasi bitis
    if (mode.id === "classic" && questionsAnswered + 1 >= mode.questionsCount) {
      setTimeout(() => finishGame(), 1500);
    }
  };

  const handleNext = () => {
    loadNewQuestion();
  };

  const handleHint = () => {
    if (!question || !player || player.hintsLeft <= 0) return;
    
    const used = useHint();
    if (!used) return;

    soundManager.play("click");
    setHintsUsed((prev) => prev + 1);

    // Yanlis bir secenegi ele
    const wrongOptions = question.options
      .map((_, i) => i)
      .filter((i) => i !== question.correctIndex && i !== eliminatedOption);
    
    if (wrongOptions.length > 0) {
      const randomWrong = wrongOptions[Math.floor(Math.random() * wrongOptions.length)];
      setEliminatedOption(randomWrong);
    }
  };

  const handleFinish = () => {
    soundManager.play("click");
    router.push("/game");
  };

  if (!topic || !question || !mode || !player || !character) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-secondary to-background">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-center"
        >
          <div className="text-5xl mb-4 animate-bounce">🧮</div>
          <div className="text-xl text-foreground">Yukleniyor...</div>
        </motion.div>
      </div>
    );
  }

  if (showResult) {
    return (
      <ResultScreen
        mode={mode}
        topic={topic}
        score={score}
        correctCount={correctCount}
        totalQuestions={questionsAnswered}
        streak={streak}
        lives={mode.livesCount ? lives : undefined}
        newLevel={showLevelUp ? newLevel : undefined}
        newBadge={newBadge}
        onContinue={() => {
          setShowResult(false);
          setGameOver(false);
          setQuestionsAnswered(0);
          setCorrectCount(0);
          setScore(0);
          setStreak(0);
          setLives(mode.livesCount || 3);
          setTimeLeft(mode.timeLimit || 60);
          loadNewQuestion();
        }}
        onFinish={handleFinish}
      />
    );
  }

  return (
    <main className="min-h-screen flex flex-col bg-gradient-to-br from-background via-secondary to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-background/80 border-b border-border/30">
        <div className="max-w-2xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleFinish}
              className="text-muted-foreground"
            >
              ✕ Cikis
            </Button>
            <div className="text-center">
              <div className="flex items-center gap-2">
                <span className="text-lg">{mode.icon}</span>
                <span className="font-semibold text-foreground">{topic.name}</span>
              </div>
              {mode.id === "classic" && (
                <p className="text-xs text-muted-foreground">
                  Soru {questionsAnswered + 1} / {mode.questionsCount}
                </p>
              )}
            </div>
            <div className="flex items-center gap-3">
              {mode.timeLimit && (
                <div className={cn(
                  "flex items-center gap-1 px-2 py-1 rounded-full text-sm font-bold",
                  timeLeft <= 10 ? "bg-destructive/20 text-destructive animate-pulse" : "bg-secondary text-foreground"
                )}>
                  ⏱️ {timeLeft}s
                </div>
              )}
              {mode.livesCount && (
                <div className="flex items-center gap-0.5">
                  {Array.from({ length: mode.livesCount }).map((_, i) => (
                    <motion.span
                      key={i}
                      initial={{ scale: 1 }}
                      animate={{ scale: i < lives ? 1 : 0.7, opacity: i < lives ? 1 : 0.3 }}
                      className="text-lg"
                    >
                      ❤️
                    </motion.span>
                  ))}
                </div>
              )}
              <div className="text-right">
                <p className="font-bold text-accent">{score}</p>
                <p className="text-xs text-muted-foreground">puan</p>
              </div>
            </div>
          </div>
          
          {/* Progress Bar */}
          {mode.id === "classic" && (
            <div className="mt-3 h-2 rounded-full bg-secondary overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${((questionsAnswered + 1) / mode.questionsCount) * 100}%` }}
                className="h-full rounded-full bg-primary"
              />
            </div>
          )}
        </div>
      </header>

      {/* Streak Indicator */}
      <AnimatePresence>
        {streak > 1 && (
          <motion.div
            initial={{ x: 100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 100, opacity: 0 }}
            className="fixed top-24 right-4 z-40"
          >
            <div className={cn(
              "px-4 py-2 rounded-full text-sm font-bold shadow-lg",
              streak >= 10 ? "bg-gradient-to-r from-yellow-500 to-orange-500 text-white" :
              streak >= 5 ? "bg-gradient-to-r from-accent to-yellow-500 text-white" :
              "bg-accent text-accent-foreground"
            )}>
              🔥 {streak}x Seri!
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Question */}
      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <motion.div
          key={question.text}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-xl space-y-6"
        >
          {/* Question Text */}
          <div className="bg-card/50 backdrop-blur-sm border border-border/30 rounded-2xl p-6">
            <p className="text-xl md:text-2xl font-medium text-foreground text-center leading-relaxed">
              {question.text}
            </p>
          </div>

          {/* Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {question.options.map((option, index) => {
              const isSelected = selectedAnswer === index;
              const isCorrectAnswer = index === question.correctIndex;
              const showCorrect = selectedAnswer !== null && isCorrectAnswer;
              const showWrong = isSelected && !isCorrect;
              const isEliminated = eliminatedOption === index;

              return (
                <motion.button
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: isEliminated ? 0.3 : 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => !isEliminated && handleAnswer(index)}
                  disabled={selectedAnswer !== null || isEliminated}
                  className={cn(
                    "p-4 rounded-xl text-left transition-all duration-200",
                    "border-2 font-medium relative overflow-hidden",
                    selectedAnswer === null && !isEliminated && "hover:scale-[1.02] hover:shadow-md",
                    selectedAnswer === null && !isEliminated && "bg-card/50 border-border/30 hover:border-primary/50",
                    showCorrect && "bg-success/20 border-success",
                    showWrong && "bg-destructive/20 border-destructive",
                    isSelected && !showWrong && !showCorrect && "border-primary",
                    selectedAnswer !== null && !isSelected && !showCorrect && "opacity-50",
                    isEliminated && "line-through"
                  )}
                >
                  <span className="flex items-center gap-3">
                    <span className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0",
                      selectedAnswer === null && !isEliminated && "bg-secondary text-foreground",
                      showCorrect && "bg-success text-success-foreground",
                      showWrong && "bg-destructive text-destructive-foreground"
                    )}>
                      {String.fromCharCode(65 + index)}
                    </span>
                    <span className={cn(
                      "text-foreground",
                      isEliminated && "text-muted-foreground"
                    )}>{option}</span>
                  </span>
                  
                  {showCorrect && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute top-2 right-2 text-xl"
                    >
                      ✓
                    </motion.div>
                  )}
                  {showWrong && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute top-2 right-2 text-xl"
                    >
                      ✗
                    </motion.div>
                  )}
                </motion.button>
              );
            })}
          </div>

          {/* Hint Button */}
          {selectedAnswer === null && player.hintsLeft > 0 && !eliminatedOption && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-center"
            >
              <Button
                variant="outline"
                size="sm"
                onClick={handleHint}
                className="text-muted-foreground"
              >
                💡 Ipucu Kullan ({player.hintsLeft - hintsUsed} kaldi)
              </Button>
            </motion.div>
          )}

          {/* Next Button */}
          <AnimatePresence>
            {selectedAnswer !== null && !gameOver && mode.id !== "classic" && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="flex justify-center"
              >
                <Button
                  size="lg"
                  onClick={handleNext}
                  className="px-8"
                >
                  Sonraki Soru →
                </Button>
              </motion.div>
            )}
            {selectedAnswer !== null && mode.id === "classic" && questionsAnswered < mode.questionsCount - 1 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="flex justify-center"
              >
                <Button
                  size="lg"
                  onClick={handleNext}
                  className="px-8"
                >
                  Sonraki Soru →
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </main>
  );
}

interface ResultScreenProps {
  mode: GameMode;
  topic: Topic;
  score: number;
  correctCount: number;
  totalQuestions: number;
  streak: number;
  lives?: number;
  newLevel?: number;
  newBadge?: string | null;
  onContinue: () => void;
  onFinish: () => void;
}

function ResultScreen({ 
  mode,
  topic, 
  score, 
  correctCount, 
  totalQuestions, 
  streak,
  lives,
  newLevel,
  newBadge,
  onContinue, 
  onFinish 
}: ResultScreenProps) {
  const accuracy = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0;
  
  let message = "";
  let emoji = "";
  
  if (accuracy >= 90) {
    message = "Muhtesem! Gercek bir matematik ustasisin!";
    emoji = "🏆";
  } else if (accuracy >= 70) {
    message = "Harika! Cok iyi gidiyorsun!";
    emoji = "⭐";
  } else if (accuracy >= 50) {
    message = "Iyi! Biraz daha pratik yaparsan daha da iyi olursun!";
    emoji = "💪";
  } else {
    message = "Vazgecme! Her denemede daha iyi olacaksin!";
    emoji = "📚";
  }

  return (
    <main className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-background via-secondary to-background">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-md space-y-6 text-center"
      >
        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 0.5, repeat: 2 }}
          className="text-8xl"
        >
          {emoji}
        </motion.div>
        
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-foreground">
            {lives === 0 ? "Oyun Bitti!" : "Tur Tamamlandi!"}
          </h1>
          <p className="text-muted-foreground flex items-center justify-center gap-2">
            <span>{mode.icon}</span>
            {mode.name} - {topic.name}
          </p>
        </div>

        {/* Level Up */}
        {newLevel && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="bg-gradient-to-r from-yellow-500/20 to-amber-500/20 border border-yellow-500/30 rounded-xl p-4"
          >
            <div className="text-4xl mb-2">🎉</div>
            <p className="text-lg font-bold text-foreground">Seviye Atladin!</p>
            <p className="text-accent font-semibold">Seviye {newLevel}</p>
          </motion.div>
        )}

        {/* New Badge */}
        {newBadge && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-r from-purple-500/20 to-violet-500/20 border border-purple-500/30 rounded-xl p-4"
          >
            <div className="text-4xl mb-2">🏅</div>
            <p className="text-lg font-bold text-foreground">Yeni Rozet!</p>
            <p className="text-purple-400 font-semibold">{newBadge}</p>
          </motion.div>
        )}

        <div className="bg-card/50 backdrop-blur-sm border border-border/30 rounded-2xl p-6 space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-3xl font-bold text-accent">{score}</p>
              <p className="text-sm text-muted-foreground">Puan</p>
            </div>
            <div>
              <p className="text-3xl font-bold text-success">{correctCount}/{totalQuestions}</p>
              <p className="text-sm text-muted-foreground">Dogru</p>
            </div>
            <div>
              <p className="text-3xl font-bold text-foreground">%{accuracy}</p>
              <p className="text-sm text-muted-foreground">Basari</p>
            </div>
          </div>
          
          {streak > 0 && (
            <div className="pt-2 border-t border-border/30">
              <p className="text-sm text-muted-foreground">En Uzun Seri</p>
              <p className="text-xl font-bold text-accent">🔥 {streak}</p>
            </div>
          )}
          
          <p className="text-foreground font-medium pt-2 border-t border-border/30">
            {message}
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <Button
            size="lg"
            onClick={onContinue}
            className="w-full"
          >
            🔄 Tekrar Oyna
          </Button>
          <Button
            variant="outline"
            size="lg"
            onClick={onFinish}
            className="w-full"
          >
            Ana Menuye Don
          </Button>
        </div>
      </motion.div>
    </main>
  );
}
