"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { getSettings, updateSettings, Settings, getPlayer } from "@/lib/storage";
import { soundManager } from "@/lib/sounds";
import { cn } from "@/lib/utils";

export default function SettingsPage() {
  const router = useRouter();
  const [settings, setSettings] = useState<Settings | null>(null);

  useEffect(() => {
    const player = getPlayer();
    if (!player) {
      router.push("/");
      return;
    }
    setSettings(getSettings());
  }, [router]);

  const handleToggle = (key: keyof Settings) => {
    if (!settings) return;
    
    const newValue = !settings[key];
    const newSettings = { ...settings, [key]: newValue };
    setSettings(newSettings);
    updateSettings({ [key]: newValue });
    
    if (key === "soundEnabled") {
      soundManager.setEnabled(newValue);
    }
    
    if (newValue && settings.soundEnabled) {
      soundManager.play("click");
    }
  };

  if (!settings) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-secondary to-background">
        <div className="animate-pulse text-2xl text-foreground">Yukleniyor...</div>
      </div>
    );
  }

  return (
    <main className="min-h-screen flex flex-col bg-gradient-to-br from-background via-secondary to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-background/80 border-b border-border/30">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              soundManager.play("click");
              router.back();
            }}
            className="text-muted-foreground"
          >
            ← Geri
          </Button>
          <h1 className="font-semibold text-foreground">Ayarlar</h1>
          <div className="w-16" />
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 p-4 py-6">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Sound Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-3"
          >
            <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <span>🔊</span> Ses Ayarlari
            </h2>
            
            <div className="bg-card/50 border border-border/30 rounded-xl divide-y divide-border/30">
              <SettingToggle
                icon="🔈"
                label="Ses Efektleri"
                description="Dogru/yanlis, buton sesleri"
                enabled={settings.soundEnabled}
                onToggle={() => handleToggle("soundEnabled")}
              />
              <SettingToggle
                icon="🎵"
                label="Muzik"
                description="Arka plan muzigi"
                enabled={settings.musicEnabled}
                onToggle={() => handleToggle("musicEnabled")}
              />
              <SettingToggle
                icon="📳"
                label="Titresim"
                description="Yanlis cevapta titresim"
                enabled={settings.vibrationEnabled}
                onToggle={() => handleToggle("vibrationEnabled")}
              />
            </div>
          </motion.div>

          {/* Game Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-3"
          >
            <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <span>ℹ️</span> Oyun Hakkinda
            </h2>
            
            <div className="bg-card/50 border border-border/30 rounded-xl p-4 space-y-4">
              <div className="text-center">
                <div className="text-5xl mb-3">🧮</div>
                <h3 className="text-xl font-bold text-foreground">Matematik Macerasi</h3>
                <p className="text-sm text-muted-foreground">Versiyon 2.0</p>
              </div>
              
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-secondary/50 rounded-lg p-3 text-center">
                  <p className="font-bold text-foreground">4</p>
                  <p className="text-muted-foreground">Dunya</p>
                </div>
                <div className="bg-secondary/50 rounded-lg p-3 text-center">
                  <p className="font-bold text-foreground">27</p>
                  <p className="text-muted-foreground">Konu</p>
                </div>
                <div className="bg-secondary/50 rounded-lg p-3 text-center">
                  <p className="font-bold text-foreground">4</p>
                  <p className="text-muted-foreground">Oyun Modu</p>
                </div>
                <div className="bg-secondary/50 rounded-lg p-3 text-center">
                  <p className="font-bold text-foreground">16</p>
                  <p className="text-muted-foreground">Rozet</p>
                </div>
              </div>
              
              <p className="text-xs text-muted-foreground text-center">
                Ortaokul ogrencileri icin egitici matematik oyunu.
                5-8. sinif mufredatina uygun, sinirsiz soru uretimi.
              </p>
            </div>
          </motion.div>

          {/* Tips */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-3"
          >
            <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
              <span>💡</span> Ipuclari
            </h2>
            
            <div className="bg-card/50 border border-border/30 rounded-xl p-4 space-y-3">
              <TipItem
                icon="🔥"
                text="Ust uste dogru cevaplar vererek seri olustur ve ekstra puan kazan!"
              />
              <TipItem
                icon="📅"
                text="Her gun giris yaparak gunluk odul ve gem kazan!"
              />
              <TipItem
                icon="⚡"
                text="Hiz Yarisi modunda 60 saniyede en cok soruyu cozmeye calis!"
              />
              <TipItem
                icon="💀"
                text="Hayatta Kal modunda 3 canla ne kadar ileri gidebilirsin?"
              />
              <TipItem
                icon="👹"
                text="Boss Savasi modunda dunya boss'larini yen ve ekstra oduller kazan!"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </main>
  );
}

interface SettingToggleProps {
  icon: string;
  label: string;
  description: string;
  enabled: boolean;
  onToggle: () => void;
}

function SettingToggle({ icon, label, description, enabled, onToggle }: SettingToggleProps) {
  return (
    <button
      onClick={onToggle}
      className="w-full flex items-center justify-between p-4 hover:bg-secondary/30 transition-colors"
    >
      <div className="flex items-center gap-3">
        <span className="text-2xl">{icon}</span>
        <div className="text-left">
          <p className="font-medium text-foreground">{label}</p>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
      <div
        className={cn(
          "w-12 h-7 rounded-full relative transition-colors",
          enabled ? "bg-primary" : "bg-secondary"
        )}
      >
        <motion.div
          initial={false}
          animate={{ x: enabled ? 22 : 2 }}
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
          className="absolute top-1 w-5 h-5 rounded-full bg-white shadow-sm"
        />
      </div>
    </button>
  );
}

function TipItem({ icon, text }: { icon: string; text: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="text-xl shrink-0">{icon}</span>
      <p className="text-sm text-muted-foreground">{text}</p>
    </div>
  );
}
