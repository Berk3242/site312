"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  getCharacterById, 
  Character, 
  worlds, 
  badges as allBadges,
  getLevelFromXP,
  getXPForNextLevel,
  getRarityColor,
} from "@/lib/game-data";
import { 
  getPlayer, 
  PlayerData, 
  calculateWorldCompletion,
  resetGame,
} from "@/lib/storage";
import { soundManager } from "@/lib/sounds";
import { cn } from "@/lib/utils";

export default function ProfilePage() {
  const router = useRouter();
  const [player, setPlayer] = useState<PlayerData | null>(null);
  const [character, setCharacter] = useState<Character | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [activeTab, setActiveTab] = useState<"stats" | "badges" | "progress">("stats");

  useEffect(() => {
    const savedPlayer = getPlayer();
    if (!savedPlayer) {
      router.push("/");
      return;
    }
    setPlayer(savedPlayer);
    setCharacter(getCharacterById(savedPlayer.character) || null);
  }, [router]);

  const handleReset = () => {
    soundManager.play("click");
    resetGame();
    router.push("/");
  };

  if (!player || !character) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-secondary to-background">
        <div className="animate-pulse text-2xl text-foreground">Yukleniyor...</div>
      </div>
    );
  }

  const level = getLevelFromXP(player.xp);
  const xpProgress = getXPForNextLevel(player.xp);
  const totalCompletion = worlds.reduce((acc, world) => {
    return acc + calculateWorldCompletion(world.id, world.topics.length);
  }, 0) / worlds.length;

  return (
    <main className="min-h-screen flex flex-col bg-gradient-to-br from-background via-secondary to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-background/80 border-b border-border/30">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              soundManager.play("click");
              router.push("/game");
            }}
            className="text-muted-foreground"
          >
            ← Geri
          </Button>
          <h1 className="font-semibold text-foreground">Profil</h1>
          <Link href="/settings">
            <Button variant="ghost" size="sm" className="text-muted-foreground">
              ⚙️
            </Button>
          </Link>
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 p-4 py-6">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Profile Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={cn(
              "relative overflow-hidden rounded-3xl p-6 text-center",
              "bg-gradient-to-br",
              character.color
            )}
          >
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-4 right-4 text-[200px]">{character.emoji}</div>
            </div>
            
            <div className="relative z-10 space-y-4">
              <div className="text-8xl">{character.emoji}</div>
              <div>
                <h2 className="text-3xl font-bold text-white">{player.name}</h2>
                <p className="text-white/70">{character.name}</p>
              </div>
              
              {/* Level Badge */}
              <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">
                <span className="text-lg">⭐</span>
                <span className="font-bold text-white">Seviye {level}</span>
              </div>
              
              {/* XP Progress */}
              <div className="max-w-xs mx-auto">
                <div className="h-3 rounded-full bg-black/30 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${xpProgress.progress}%` }}
                    className="h-full rounded-full bg-white/80"
                  />
                </div>
                <p className="text-xs text-white/60 mt-1">
                  {xpProgress.current} / {xpProgress.needed} XP
                </p>
              </div>
              
              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-4 pt-4">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
                  <p className="text-2xl font-bold text-white">{player.xp}</p>
                  <p className="text-xs text-white/60">Toplam XP</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
                  <p className="text-2xl font-bold text-white">{player.badges.length}</p>
                  <p className="text-xs text-white/60">Rozet</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
                  <p className="text-2xl font-bold text-white">{player.gems}</p>
                  <p className="text-xs text-white/60">💎 Gem</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Tab Navigation */}
          <div className="flex gap-2 bg-card/50 p-1 rounded-xl">
            {[
              { id: "stats", label: "Istatistikler", icon: "📊" },
              { id: "badges", label: "Rozetler", icon: "🏅" },
              { id: "progress", label: "Ilerleme", icon: "📈" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  soundManager.play("click");
                  setActiveTab(tab.id as typeof activeTab);
                }}
                className={cn(
                  "flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-sm font-medium transition-all",
                  activeTab === tab.id
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <span>{tab.icon}</span>
                <span className="hidden sm:inline">{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Tab Content */}
          {activeTab === "stats" && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <div className="grid grid-cols-2 gap-3">
                <StatCard icon="📝" label="Cozulen Soru" value={player.stats.totalQuestions} />
                <StatCard icon="✅" label="Dogru Cevap" value={player.stats.totalCorrect} />
                <StatCard icon="🔥" label="En Iyi Seri" value={player.stats.bestStreak} />
                <StatCard icon="👹" label="Yenilen Boss" value={player.stats.bossesDefeated} />
                <StatCard icon="⚡" label="Hiz Rekoru" value={player.stats.speedModeHighScore} />
                <StatCard icon="💀" label="Hayatta Kal Rekoru" value={player.stats.survivalModeHighScore} />
              </div>
              
              {/* Accuracy */}
              {player.stats.totalQuestions > 0 && (
                <div className="bg-card/50 border border-border/30 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-muted-foreground">Genel Basari Orani</span>
                    <span className="font-bold text-foreground">
                      %{Math.round((player.stats.totalCorrect / player.stats.totalQuestions) * 100)}
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-secondary overflow-hidden">
                    <div
                      className="h-full rounded-full bg-success"
                      style={{ width: `${(player.stats.totalCorrect / player.stats.totalQuestions) * 100}%` }}
                    />
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === "badges" && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <p className="text-sm text-muted-foreground text-center">
                {player.badges.length} / {allBadges.length} rozet kazanildi
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {allBadges.map((badge, index) => {
                  const earned = player.badges.includes(badge.id);
                  return (
                    <motion.div
                      key={badge.id}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.05 }}
                      className={cn(
                        "p-4 rounded-xl text-center transition-all border",
                        earned 
                          ? `bg-gradient-to-br ${getRarityColor(badge.rarity)} border-white/20` 
                          : "bg-card/30 border-border/20"
                      )}
                    >
                      <span className={cn("text-4xl block mb-2", !earned && "grayscale opacity-30")}>
                        {badge.icon}
                      </span>
                      <p className={cn(
                        "text-xs font-medium mb-1",
                        earned ? "text-white" : "text-muted-foreground"
                      )}>
                        {badge.name}
                      </p>
                      {earned && (
                        <p className="text-xs text-white/60">{badge.description}</p>
                      )}
                      {!earned && (
                        <p className="text-xs text-muted-foreground/50">???</p>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          )}

          {activeTab === "progress" && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <div className="bg-card/50 border border-border/30 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-muted-foreground">Genel Ilerleme</span>
                  <span className="font-bold text-foreground">%{Math.round(totalCompletion)}</span>
                </div>
                <div className="h-3 rounded-full bg-secondary overflow-hidden">
                  <div
                    className={cn(
                      "h-full rounded-full",
                      totalCompletion >= 100 ? "bg-success" : "bg-primary"
                    )}
                    style={{ width: `${totalCompletion}%` }}
                  />
                </div>
              </div>
              
              {worlds.map((world, index) => {
                const completion = calculateWorldCompletion(world.id, world.topics.length);
                return (
                  <motion.div
                    key={world.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-card/50 border border-border/30 rounded-xl p-4"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{world.icon}</span>
                        <div>
                          <span className="font-medium text-foreground">{world.name}</span>
                          <span className="text-xs text-muted-foreground ml-2">{world.grade}. Sinif</span>
                        </div>
                      </div>
                      <span className="text-sm font-medium text-accent">%{completion}</span>
                    </div>
                    <div className="h-2 rounded-full bg-secondary overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${completion}%` }}
                        transition={{ duration: 0.5, delay: index * 0.1 }}
                        className={cn(
                          "h-full rounded-full",
                          completion >= 100 ? "bg-success" : "bg-primary"
                        )}
                      />
                    </div>
                    {completion === 100 && (
                      <p className="text-xs text-success mt-1 flex items-center gap-1">
                        <span>⭐</span> Tamamlandi!
                      </p>
                    )}
                  </motion.div>
                );
              })}
            </motion.div>
          )}

          {/* Actions */}
          <div className="space-y-3 pt-4">
            <Link href="/leaderboard">
              <Button variant="outline" className="w-full">
                🏆 Liderlik Tablosu
              </Button>
            </Link>
            
            <Button
              variant="ghost"
              onClick={() => setShowResetConfirm(true)}
              className="w-full text-destructive hover:text-destructive hover:bg-destructive/10"
            >
              Oyunu Sifirla
            </Button>
          </div>
        </div>
      </div>

      {/* Reset Confirm Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-card p-6 rounded-2xl max-w-sm w-full space-y-4"
          >
            <div className="text-center">
              <span className="text-5xl block mb-3">⚠️</span>
              <h2 className="text-xl font-bold text-foreground">Emin misin?</h2>
              <p className="text-muted-foreground mt-2">
                Tum ilerleme, puanlar, rozetler ve gem&apos;ler silinecek. Bu islem geri alinamaz.
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowResetConfirm(false)}
                className="flex-1"
              >
                Iptal
              </Button>
              <Button
                variant="destructive"
                onClick={handleReset}
                className="flex-1"
              >
                Sifirla
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </main>
  );
}

function StatCard({ icon, label, value }: { icon: string; label: string; value: number }) {
  return (
    <div className="bg-card/50 border border-border/30 rounded-xl p-4 text-center">
      <span className="text-2xl block mb-1">{icon}</span>
      <p className="text-2xl font-bold text-foreground">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
