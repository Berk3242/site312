import type { Metadata, Viewport } from 'next'
import { Nunito, Fredoka } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const nunito = Nunito({ 
  subsets: ["latin"],
  variable: "--font-nunito",
});

const fredoka = Fredoka({ 
  subsets: ["latin"],
  variable: "--font-fredoka",
});

export const metadata: Metadata = {
  title: 'Matematik Macerasi - Ortaokul Matematik Oyunu',
  description: 'Ortaokul ogrencileri icin egitici ve eglenceli matematik oyunu. 5-8. sinif konulari, otomatik soru uretimi, rozetler ve liderlik tablosu.',
  keywords: ['matematik', 'oyun', 'egitim', 'ortaokul', '5. sinif', '6. sinif', '7. sinif', '8. sinif'],
}

export const viewport: Viewport = {
  themeColor: '#1a1625',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="tr" className="bg-background">
      <body className={`${nunito.variable} ${fredoka.variable} font-sans antialiased min-h-screen`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
