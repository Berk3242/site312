"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { getPlayer, checkAndUpdateDailyLogin } from "@/lib/storage";
import { soundManager } from "@/lib/sounds";
import { getLevelFromXP, getXPForNextLevel } from "@/lib/game-data";
import { triggerConfetti } from "@/components/confetti";

export default function HomePage() {
  const router = useRouter();
  const [hasPlayer, setHasPlayer] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showDailyBonus, setShowDailyBonus] = useState(false);
  const [dailyBonusData, setDailyBonusData] = useState<{ streak: number; reward: number } | null>(null);

  useEffect(() => {
    const player = getPlayer();
    setHasPlayer(!!player);
    setIsLoading(false);

    // Gunluk giris kontrolu
    if (player) {
      const { isNewDay, loginStreak, bonusReward } = checkAndUpdateDailyLogin();
      if (isNewDay && bonusReward > 0) {
        setDailyBonusData({ streak: loginStreak, reward: bonusReward });
        setShowDailyBonus(true);
        setTimeout(() => {
          triggerConfetti("success");
        }, 300);
      }
    }
  }, []);

  const handleStart = () => {
    soundManager.play("click");
    if (hasPlayer) {
      router.push("/game");
    } else {
      router.push("/character");
    }
  };

  const handleNewGame = () => {
    soundManager.play("click");
    router.push("/character");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-secondary to-background">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-center"
        >
          <div className="text-6xl mb-4 animate-bounce">🧮</div>
          <div className="text-xl text-foreground">Yukleniyor...</div>
        </motion.div>
      </div>
    );
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-background via-secondary to-background overflow-hidden relative">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{ duration: 4, repeat: Infinity }}
          className="absolute top-20 left-10 w-40 h-40 bg-emerald-500/30 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.15, 0.25, 0.15],
          }}
          transition={{ duration: 5, repeat: Infinity }}
          className="absolute top-40 right-10 w-48 h-48 bg-blue-500/30 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{ duration: 6, repeat: Infinity }}
          className="absolute bottom-32 left-1/4 w-44 h-44 bg-violet-500/30 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.1, 1, 1.1],
            opacity: [0.15, 0.25, 0.15],
          }}
          transition={{ duration: 4.5, repeat: Infinity }}
          className="absolute bottom-20 right-1/4 w-36 h-36 bg-orange-500/30 rounded-full blur-3xl"
        />
        
        {/* Floating Math Symbols */}
        {["+", "-", "×", "÷", "=", "π", "∑", "√"].map((symbol, i) => (
          <motion.div
            key={symbol}
            className="absolute text-4xl text-foreground/10 font-bold"
            style={{
              left: `${10 + (i * 12)}%`,
              top: `${20 + (i % 3) * 25}%`,
            }}
            animate={{
              y: [0, -20, 0],
              rotate: [0, 10, -10, 0],
            }}
            transition={{
              duration: 3 + i * 0.5,
              repeat: Infinity,
              delay: i * 0.3,
            }}
          >
            {symbol}
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 flex flex-col items-center gap-8 max-w-lg w-full"
      >
        {/* Logo and Title */}
        <div className="text-center space-y-4">
          <motion.div
            animate={{ 
              y: [0, -10, 0],
              rotate: [0, 5, -5, 0],
            }}
            transition={{ duration: 2, repeat: Infinity }}
            className="text-8xl md:text-9xl"
          >
            🧮
          </motion.div>
          <h1 className="text-4xl md:text-6xl font-bold text-foreground tracking-tight text-balance bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text">
            Matematik Macerasi
          </h1>
          <p className="text-lg text-muted-foreground text-pretty max-w-xs mx-auto">
            Ortaokul matematik konularini oynayarak ogren, maceraya katil!
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-2 gap-3 w-full max-w-sm">
          <FeatureCard icon="🗺️" text="4 Dunya" color="from-emerald-500/20 to-green-500/20" />
          <FeatureCard icon="⚔️" text="Boss Savas" color="from-red-500/20 to-orange-500/20" />
          <FeatureCard icon="⚡" text="Hiz Yarisi" color="from-yellow-500/20 to-amber-500/20" />
          <FeatureCard icon="🏆" text="Rozetler" color="from-violet-500/20 to-purple-500/20" />
        </div>

        {/* Game Modes Preview */}
        <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <span className="text-lg">📚</span> Klasik
          </span>
          <span className="text-border">•</span>
          <span className="flex items-center gap-1">
            <span className="text-lg">⚡</span> Hizli
          </span>
          <span className="text-border">•</span>
          <span className="flex items-center gap-1">
            <span className="text-lg">💀</span> Hayatta Kal
          </span>
        </div>

        {/* Buttons */}
        <div className="flex flex-col gap-3 w-full max-w-xs">
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              size="lg"
              onClick={handleStart}
              className="w-full h-14 text-lg font-semibold bg-gradient-to-r from-primary via-primary/90 to-primary shadow-lg shadow-primary/30 hover:shadow-primary/50 transition-all"
            >
              {hasPlayer ? "🎮 Maceraya Devam" : "🚀 Maceraya Basla"}
            </Button>
          </motion.div>
          
          {hasPlayer && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Button
                variant="outline"
                size="lg"
                onClick={handleNewGame}
                className="w-full h-12 text-base border-border/50 hover:bg-secondary/50"
              >
                Yeni Karakter Olustur
              </Button>
            </motion.div>
          )}
        </div>

        {/* Footer */}
        <p className="text-sm text-muted-foreground/60 text-center">
          5. - 8. sinif matematik mufredati • Sinirsiz soru
        </p>
      </motion.div>

      {/* Daily Bonus Modal */}
      <AnimatePresence>
        {showDailyBonus && dailyBonusData && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 20 }}
              className="bg-card border border-border/30 p-8 rounded-3xl max-w-sm w-full text-center space-y-6"
            >
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 0.5, repeat: 2 }}
                className="text-7xl"
              >
                🎁
              </motion.div>
              <div className="space-y-2">
                <h2 className="text-2xl font-bold text-foreground">Gunluk Odul!</h2>
                <p className="text-muted-foreground">
                  {dailyBonusData.streak} gun ust uste giris yaptin!
                </p>
              </div>
              <div className="bg-gradient-to-r from-yellow-500/20 to-amber-500/20 rounded-xl p-4">
                <div className="flex items-center justify-center gap-2">
                  <span className="text-3xl">💎</span>
                  <span className="text-3xl font-bold text-accent">+{dailyBonusData.reward}</span>
                </div>
                <p className="text-sm text-muted-foreground mt-1">Gem kazandin!</p>
              </div>
              {dailyBonusData.streak % 7 === 0 && (
                <p className="text-sm text-yellow-500 font-medium">
                  🎉 Haftalik bonus dahil!
                </p>
              )}
              <Button
                onClick={() => {
                  soundManager.play("click");
                  setShowDailyBonus(false);
                }}
                className="w-full"
              >
                Harika!
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}

function FeatureCard({ icon, text, color }: { icon: string; text: string; color: string }) {
  return (
    <motion.div
      whileHover={{ scale: 1.05, y: -2 }}
      className={`flex items-center gap-3 p-4 rounded-xl bg-gradient-to-br ${color} border border-border/30 backdrop-blur-sm`}
    >
      <span className="text-2xl">{icon}</span>
      <span className="text-sm font-semibold text-foreground">{text}</span>
    </motion.div>
  );
}
