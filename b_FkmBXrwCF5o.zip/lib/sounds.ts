// Ses Efektleri Yonetimi

type SoundType = "correct" | "wrong" | "levelup" | "badge" | "click";

class SoundManager {
  private audioContext: AudioContext | null = null;
  private enabled: boolean = true;

  private getAudioContext(): AudioContext {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    }
    return this.audioContext;
  }

  setEnabled(enabled: boolean): void {
    this.enabled = enabled;
  }

  isEnabled(): boolean {
    return this.enabled;
  }

  private playTone(frequency: number, duration: number, type: OscillatorType = "sine"): void {
    if (!this.enabled || typeof window === "undefined") return;

    try {
      const ctx = this.getAudioContext();
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);

      oscillator.frequency.value = frequency;
      oscillator.type = type;

      gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);

      oscillator.start(ctx.currentTime);
      oscillator.stop(ctx.currentTime + duration);
    } catch {
      // Ses calma basarisiz, sessizce devam et
    }
  }

  private playMelody(notes: { freq: number; dur: number }[]): void {
    if (!this.enabled || typeof window === "undefined") return;

    try {
      const ctx = this.getAudioContext();
      let time = ctx.currentTime;

      notes.forEach(({ freq, dur }) => {
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);

        oscillator.frequency.value = freq;
        oscillator.type = "sine";

        gainNode.gain.setValueAtTime(0.3, time);
        gainNode.gain.exponentialRampToValueAtTime(0.01, time + dur);

        oscillator.start(time);
        oscillator.stop(time + dur);

        time += dur * 0.8;
      });
    } catch {
      // Ses calma basarisiz
    }
  }

  play(sound: SoundType): void {
    switch (sound) {
      case "correct":
        // Mutlu, yukari cikan melodii
        this.playMelody([
          { freq: 523.25, dur: 0.1 }, // C5
          { freq: 659.25, dur: 0.1 }, // E5
          { freq: 783.99, dur: 0.15 }, // G5
        ]);
        break;

      case "wrong":
        // Kisa, dusuk ton
        this.playMelody([
          { freq: 311.13, dur: 0.15 }, // Eb4
          { freq: 261.63, dur: 0.2 }, // C4
        ]);
        break;

      case "levelup":
        // Zafer melodisi
        this.playMelody([
          { freq: 523.25, dur: 0.1 }, // C5
          { freq: 587.33, dur: 0.1 }, // D5
          { freq: 659.25, dur: 0.1 }, // E5
          { freq: 698.46, dur: 0.1 }, // F5
          { freq: 783.99, dur: 0.2 }, // G5
          { freq: 1046.5, dur: 0.3 }, // C6
        ]);
        break;

      case "badge":
        // Ozel basari melodisi
        this.playMelody([
          { freq: 783.99, dur: 0.1 }, // G5
          { freq: 987.77, dur: 0.1 }, // B5
          { freq: 1174.66, dur: 0.1 }, // D6
          { freq: 1567.98, dur: 0.3 }, // G6
        ]);
        break;

      case "click":
        this.playTone(800, 0.05, "square");
        break;
    }
  }
}

export const soundManager = new SoundManager();
