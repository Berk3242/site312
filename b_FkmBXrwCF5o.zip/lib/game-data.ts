// Oyun Verileri - Dunyalar, Konular, Karakterler ve Oyun Modlari

export interface Character {
  id: string;
  name: string;
  emoji: string;
  description: string;
  color: string;
  power: string;
  powerDescription: string;
}

export interface Topic {
  id: string;
  name: string;
  description: string;
  grade: 5 | 6 | 7 | 8;
  worldId: string;
  difficulty: 1 | 2 | 3;
  icon: string;
}

export interface World {
  id: string;
  name: string;
  grade: 5 | 6 | 7 | 8;
  description: string;
  color: string;
  bgGradient: string;
  icon: string;
  bossName: string;
  bossEmoji: string;
  topics: Topic[];
}

export interface GameMode {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  questionsCount: number;
  timeLimit?: number; // saniye cinsinden
  livesCount?: number;
  pointsMultiplier: number;
}

export interface DailyChallenge {
  id: string;
  name: string;
  description: string;
  icon: string;
  requirement: number;
  reward: number;
  type: "questions" | "correct" | "streak" | "worlds";
}

export const characters: Character[] = [
  {
    id: "owl",
    name: "Bilge Baykus",
    emoji: "🦉",
    description: "Bilgelik ve sabir ile her soruyu cozer",
    color: "from-amber-500 to-orange-600",
    power: "Ipucu Ustasi",
    powerDescription: "Her 5 soruda bir ucretsiz ipucu",
  },
  {
    id: "lion",
    name: "Cesur Aslan",
    emoji: "🦁",
    description: "Korkusuzca her zorlugun ustesinden gelir",
    color: "from-yellow-500 to-amber-600",
    power: "Ikinci Sans",
    powerDescription: "Yanlis cevapta bir kere daha deneme hakki",
  },
  {
    id: "rabbit",
    name: "Hizli Tavsan",
    emoji: "🐰",
    description: "Cevikligi ile sorulari hizla cozer",
    color: "from-pink-500 to-rose-600",
    power: "Zaman Bonusu",
    powerDescription: "Hizli cevaplarda ekstra puan",
  },
  {
    id: "fox",
    name: "Akilli Tilki",
    emoji: "🦊",
    description: "Zekasiyla en zor problemleri bile cozer",
    color: "from-orange-500 to-red-600",
    power: "Secenek Eleme",
    powerDescription: "Bir yanlis secenegi elemede yardim",
  },
];

export const gameModes: GameMode[] = [
  {
    id: "classic",
    name: "Klasik Mod",
    description: "10 soru, kendi hizinda cozdugu",
    icon: "📚",
    color: "from-blue-500 to-cyan-600",
    questionsCount: 10,
    pointsMultiplier: 1,
  },
  {
    id: "speed",
    name: "Hiz Yarisi",
    description: "60 saniyede en cok soruyu coz!",
    icon: "⚡",
    color: "from-yellow-500 to-orange-600",
    questionsCount: 999,
    timeLimit: 60,
    pointsMultiplier: 1.5,
  },
  {
    id: "survival",
    name: "Hayatta Kal",
    description: "3 can ile ne kadar ileri gidebilirsin?",
    icon: "💀",
    color: "from-red-500 to-rose-600",
    questionsCount: 999,
    livesCount: 3,
    pointsMultiplier: 2,
  },
  {
    id: "boss",
    name: "Boss Savasi",
    description: "Dunya boss'una karsi mucadele!",
    icon: "👹",
    color: "from-purple-500 to-violet-600",
    questionsCount: 15,
    livesCount: 5,
    pointsMultiplier: 3,
  },
];

export const dailyChallenges: DailyChallenge[] = [
  {
    id: "solve-20",
    name: "Gunluk Pratik",
    description: "20 soru coz",
    icon: "📝",
    requirement: 20,
    reward: 50,
    type: "questions",
  },
  {
    id: "correct-15",
    name: "Dogruluk Ustasi",
    description: "15 dogru cevap ver",
    icon: "✅",
    requirement: 15,
    reward: 75,
    type: "correct",
  },
  {
    id: "streak-5",
    name: "Seri Avcisi",
    description: "5'li seri yap",
    icon: "🔥",
    requirement: 5,
    reward: 100,
    type: "streak",
  },
  {
    id: "explore-2",
    name: "Kaşif",
    description: "2 farkli dunyada oyna",
    icon: "🗺️",
    requirement: 2,
    reward: 60,
    type: "worlds",
  },
];

// XP ve seviye sistemi
export const levelThresholds = [
  0, 100, 250, 500, 800, 1200, 1700, 2300, 3000, 4000,
  5000, 6500, 8000, 10000, 12500, 15000, 18000, 22000, 27000, 33000,
  40000, 50000, 65000, 85000, 100000
];

export function getLevelFromXP(xp: number): number {
  for (let i = levelThresholds.length - 1; i >= 0; i--) {
    if (xp >= levelThresholds[i]) return i + 1;
  }
  return 1;
}

export function getXPForNextLevel(currentXP: number): { current: number; needed: number; progress: number } {
  const level = getLevelFromXP(currentXP);
  const currentThreshold = levelThresholds[level - 1] || 0;
  const nextThreshold = levelThresholds[level] || levelThresholds[levelThresholds.length - 1];
  
  const current = currentXP - currentThreshold;
  const needed = nextThreshold - currentThreshold;
  const progress = Math.min((current / needed) * 100, 100);
  
  return { current, needed, progress };
}

export const worlds: World[] = [
  {
    id: "sayi-kralligi",
    name: "Sayi Kralligi",
    grade: 5,
    description: "Dogal sayilar, kesirler ve temel islemler",
    color: "from-emerald-500 to-green-600",
    bgGradient: "bg-gradient-to-br from-emerald-900/50 to-green-900/50",
    icon: "👑",
    bossName: "Sayi Canavari",
    bossEmoji: "🐉",
    topics: [
      { id: "dogal-sayilar", name: "Dogal Sayilar", description: "Toplama, cikarma, carpma ve bolme", grade: 5, worldId: "sayi-kralligi", difficulty: 1, icon: "🔢" },
      { id: "kesirler-5", name: "Kesirler", description: "Kesir karsilastirma ve islemler", grade: 5, worldId: "sayi-kralligi", difficulty: 2, icon: "🥧" },
      { id: "ondalik-gosterim", name: "Ondalik Gosterim", description: "Ondalik sayilarla islemler", grade: 5, worldId: "sayi-kralligi", difficulty: 2, icon: "🔵" },
      { id: "yuzde-hesaplama", name: "Yuzde Hesaplama", description: "Yuzde kavramlari ve hesaplama", grade: 5, worldId: "sayi-kralligi", difficulty: 2, icon: "💯" },
      { id: "alan-cevre", name: "Alan ve Cevre", description: "Dikdortgen ve kare hesaplari", grade: 5, worldId: "sayi-kralligi", difficulty: 1, icon: "📐" },
      { id: "acilar", name: "Acilar", description: "Aci olcme ve hesaplama", grade: 5, worldId: "sayi-kralligi", difficulty: 2, icon: "📏" },
      { id: "cokgenler", name: "Cokgenler", description: "Cokgen ozellikleri", grade: 5, worldId: "sayi-kralligi", difficulty: 3, icon: "🔷" },
    ],
  },
  {
    id: "kesir-okyanusu",
    name: "Kesir Okyanusu",
    grade: 6,
    description: "Tam sayilar, oran-oranti ve cebire giris",
    color: "from-blue-500 to-cyan-600",
    bgGradient: "bg-gradient-to-br from-blue-900/50 to-cyan-900/50",
    icon: "🌊",
    bossName: "Dalga Kaptani",
    bossEmoji: "🦑",
    topics: [
      { id: "tam-sayilar", name: "Tam Sayilar", description: "Pozitif ve negatif sayilar", grade: 6, worldId: "kesir-okyanusu", difficulty: 1, icon: "➕" },
      { id: "kesirlerde-islemler", name: "Kesirlerde Islemler", description: "Kesirlerle carpma ve bolme", grade: 6, worldId: "kesir-okyanusu", difficulty: 2, icon: "🍰" },
      { id: "oran-oranti", name: "Oran ve Oranti", description: "Oran kavramlari ve problemler", grade: 6, worldId: "kesir-okyanusu", difficulty: 2, icon: "⚖️" },
      { id: "cebire-giris", name: "Cebire Giris", description: "Basit denklemler ve degiskenler", grade: 6, worldId: "kesir-okyanusu", difficulty: 3, icon: "🔤" },
      { id: "daire", name: "Daire", description: "Daire cevresi ve alani", grade: 6, worldId: "kesir-okyanusu", difficulty: 2, icon: "⭕" },
      { id: "veri-analizi", name: "Veri Analizi", description: "Ortalama, ortanca ve mod", grade: 6, worldId: "kesir-okyanusu", difficulty: 2, icon: "📊" },
    ],
  },
  {
    id: "cebir-ormani",
    name: "Cebir Ormani",
    grade: 7,
    description: "Cebirsel ifadeler, esitsizlikler ve olasilik",
    color: "from-violet-500 to-purple-600",
    bgGradient: "bg-gradient-to-br from-violet-900/50 to-purple-900/50",
    icon: "🌲",
    bossName: "Orman Ruhu",
    bossEmoji: "🧙",
    topics: [
      { id: "rasyonel-sayilar", name: "Rasyonel Sayilar", description: "Rasyonel sayi islemleri", grade: 7, worldId: "cebir-ormani", difficulty: 2, icon: "🔢" },
      { id: "cebirsel-ifadeler", name: "Cebirsel Ifadeler", description: "Ifade sadelelestirme", grade: 7, worldId: "cebir-ormani", difficulty: 2, icon: "✖️" },
      { id: "esitsizlikler", name: "Esitsizlikler", description: "Esitsizlik cozme", grade: 7, worldId: "cebir-ormani", difficulty: 2, icon: "📉" },
      { id: "dogrusal-denklemler", name: "Dogrusal Denklemler", description: "Birinci dereceden denklemler", grade: 7, worldId: "cebir-ormani", difficulty: 3, icon: "📈" },
      { id: "ucgenler", name: "Ucgenler", description: "Ucgen ozellikleri ve alan", grade: 7, worldId: "cebir-ormani", difficulty: 2, icon: "🔺" },
      { id: "cember-daire", name: "Cember ve Daire", description: "Yay uzunlugu ve daire dilimi", grade: 7, worldId: "cebir-ormani", difficulty: 3, icon: "🎯" },
      { id: "olasilik-7", name: "Olasilik", description: "Basit olasilik hesaplama", grade: 7, worldId: "cebir-ormani", difficulty: 2, icon: "🎲" },
    ],
  },
  {
    id: "geometri-kalesi",
    name: "Geometri Kalesi",
    grade: 8,
    description: "Uslu sayilar, denklem sistemleri ve Pisagor",
    color: "from-orange-500 to-red-600",
    bgGradient: "bg-gradient-to-br from-orange-900/50 to-red-900/50",
    icon: "🏰",
    bossName: "Kale Lordu",
    bossEmoji: "👑",
    topics: [
      { id: "uslu-sayilar", name: "Uslu Sayilar", description: "Uslu ifade islemleri", grade: 8, worldId: "geometri-kalesi", difficulty: 2, icon: "²" },
      { id: "koklu-sayilar", name: "Koklu Sayilar", description: "Karekoklu islemler", grade: 8, worldId: "geometri-kalesi", difficulty: 2, icon: "√" },
      { id: "denklem-sistemleri", name: "Denklem Sistemleri", description: "Iki bilinmeyenli denklemler", grade: 8, worldId: "geometri-kalesi", difficulty: 3, icon: "🔀" },
      { id: "esitsizlik-sistemleri", name: "Esitsizlik Sistemleri", description: "Esitsizlik cozumleri", grade: 8, worldId: "geometri-kalesi", difficulty: 3, icon: "📊" },
      { id: "ucgen-eslik-benzerlik", name: "Ucgende Eslik ve Benzerlik", description: "Eslik ve benzerlik", grade: 8, worldId: "geometri-kalesi", difficulty: 3, icon: "🔶" },
      { id: "pisagor-teoremi", name: "Pisagor Teoremi", description: "a² + b² = c² uygulamalari", grade: 8, worldId: "geometri-kalesi", difficulty: 2, icon: "📐" },
      { id: "olasilik-8", name: "Olasilik (Ileri)", description: "Birlesik olasilik", grade: 8, worldId: "geometri-kalesi", difficulty: 3, icon: "🎰" },
      { id: "fonksiyonlar", name: "Fonksiyonlar", description: "f(x) hesaplamalari", grade: 8, worldId: "geometri-kalesi", difficulty: 3, icon: "📈" },
    ],
  },
];

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  condition: string;
  rarity: "common" | "rare" | "epic" | "legendary";
}

export const badges: Badge[] = [
  { id: "baslangic-kahramani", name: "Baslangic Kahramani", description: "Ilk soruyu cozdugun icin!", icon: "🎯", condition: "firstQuestion", rarity: "common" },
  { id: "sayi-ustasi", name: "Sayi Ustasi", description: "5. sinif konularini tamamladin!", icon: "👑", condition: "completeWorld:sayi-kralligi", rarity: "rare" },
  { id: "kesir-kaptani", name: "Kesir Kaptani", description: "6. sinif konularini tamamladin!", icon: "🌊", condition: "completeWorld:kesir-okyanusu", rarity: "rare" },
  { id: "cebir-savascisi", name: "Cebir Savascisi", description: "7. sinif konularini tamamladin!", icon: "🌲", condition: "completeWorld:cebir-ormani", rarity: "rare" },
  { id: "geometri-gurusu", name: "Geometri Gurusu", description: "8. sinif konularini tamamladin!", icon: "🏰", condition: "completeWorld:geometri-kalesi", rarity: "rare" },
  { id: "mukemmeliyetci", name: "Mukemmeliyetci", description: "10 ust uste dogru cevap!", icon: "⭐", condition: "streak:10", rarity: "epic" },
  { id: "hizli-dusunur", name: "Hizli Dusunur", description: "Hiz yarisinda 20+ soru!", icon: "⚡", condition: "speed:20", rarity: "epic" },
  { id: "matematik-efendisi", name: "Matematik Efendisi", description: "Tum dunylari tamamladin!", icon: "🏆", condition: "completeAll", rarity: "legendary" },
  { id: "boss-avcisi", name: "Boss Avcisi", description: "Ilk boss'u yendin!", icon: "👹", condition: "firstBoss", rarity: "rare" },
  { id: "gunluk-kahraman", name: "Gunluk Kahraman", description: "7 gun ust uste giris yap!", icon: "📅", condition: "dailyStreak:7", rarity: "epic" },
  { id: "hayatta-kalan", name: "Hayatta Kalan", description: "Hayatta Kal modunda 20 soru!", icon: "💀", condition: "survival:20", rarity: "epic" },
  { id: "level-10", name: "Caylak Matematik", description: "Seviye 10'a ulas!", icon: "🌟", condition: "level:10", rarity: "common" },
  { id: "level-25", name: "Deneyimli Matematik", description: "Seviye 25'e ulas!", icon: "💫", condition: "level:25", rarity: "rare" },
  { id: "level-50", name: "Usta Matematik", description: "Seviye 50'ye ulas!", icon: "✨", condition: "level:50", rarity: "legendary" },
  { id: "seri-20", name: "Ates Toprak", description: "20'li seri yap!", icon: "🔥", condition: "streak:20", rarity: "legendary" },
  { id: "bin-soru", name: "Soru Canavarı", description: "1000 soru coz!", icon: "📚", condition: "totalQuestions:1000", rarity: "legendary" },
];

export function getWorldById(id: string): World | undefined {
  return worlds.find((w) => w.id === id);
}

export function getTopicById(topicId: string): Topic | undefined {
  for (const world of worlds) {
    const topic = world.topics.find((t) => t.id === topicId);
    if (topic) return topic;
  }
  return undefined;
}

export function getCharacterById(id: string): Character | undefined {
  return characters.find((c) => c.id === id);
}

export function getGameModeById(id: string): GameMode | undefined {
  return gameModes.find((m) => m.id === id);
}

export function getBadgeById(id: string): Badge | undefined {
  return badges.find((b) => b.id === id);
}

export function getRarityColor(rarity: Badge["rarity"]): string {
  switch (rarity) {
    case "common": return "from-gray-400 to-gray-500";
    case "rare": return "from-blue-400 to-blue-500";
    case "epic": return "from-purple-400 to-purple-500";
    case "legendary": return "from-yellow-400 to-orange-500";
  }
}
