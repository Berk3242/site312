// LocalStorage Yonetimi - Gelismis Sistem

import { getLevelFromXP, dailyChallenges } from "./game-data";

export interface TopicProgress {
  completed: number;
  correct: number;
  wrong: number;
  bestStreak: number;
  lastPlayed?: string;
}

export interface WorldProgress {
  [topicId: string]: TopicProgress;
}

export interface DailyChallengeProgress {
  id: string;
  current: number;
  completed: boolean;
  claimedReward: boolean;
}

export interface DailyData {
  date: string;
  questionsAnswered: number;
  correctAnswers: number;
  bestStreak: number;
  worldsPlayed: string[];
  challenges: DailyChallengeProgress[];
  loginStreak: number;
  bonusClaimed: boolean;
}

export interface LeaderboardEntry {
  name: string;
  score: number;
  character: string;
  level: number;
  date: string;
}

export interface PlayerStats {
  totalQuestions: number;
  totalCorrect: number;
  totalWrong: number;
  bestStreak: number;
  totalPlayTime: number; // dakika
  bossesDefeated: number;
  speedModeHighScore: number;
  survivalModeHighScore: number;
}

export interface PlayerData {
  name: string;
  character: string;
  xp: number;
  gems: number;
  badges: string[];
  createdAt: string;
  lastLoginDate: string;
  loginStreak: number;
  stats: PlayerStats;
  powerUsesLeft: number;
  hintsLeft: number;
}

export interface Settings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  vibrationEnabled: boolean;
  language: string;
}

export interface GameState {
  player: PlayerData | null;
  progress: { [worldId: string]: WorldProgress };
  leaderboard: LeaderboardEntry[];
  daily: DailyData | null;
  settings: Settings;
}

const STORAGE_KEY = "matematik-macerasi-v2";

const defaultSettings: Settings = {
  soundEnabled: true,
  musicEnabled: true,
  vibrationEnabled: true,
  language: "tr",
};

const defaultStats: PlayerStats = {
  totalQuestions: 0,
  totalCorrect: 0,
  totalWrong: 0,
  bestStreak: 0,
  totalPlayTime: 0,
  bossesDefeated: 0,
  speedModeHighScore: 0,
  survivalModeHighScore: 0,
};

const defaultState: GameState = {
  player: null,
  progress: {},
  leaderboard: [],
  daily: null,
  settings: defaultSettings,
};

function getTodayDate(): string {
  return new Date().toISOString().split("T")[0];
}

function createDailyData(loginStreak: number): DailyData {
  return {
    date: getTodayDate(),
    questionsAnswered: 0,
    correctAnswers: 0,
    bestStreak: 0,
    worldsPlayed: [],
    challenges: dailyChallenges.map((c) => ({
      id: c.id,
      current: 0,
      completed: false,
      claimedReward: false,
    })),
    loginStreak,
    bonusClaimed: false,
  };
}

export function getGameState(): GameState {
  if (typeof window === "undefined") return defaultState;
  
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const state = JSON.parse(stored);
      // Settings yoksa ekle
      if (!state.settings) {
        state.settings = defaultSettings;
      }
      return state;
    }
  } catch {
    console.error("LocalStorage okuma hatasi");
  }
  return defaultState;
}

export function saveGameState(state: GameState): void {
  if (typeof window === "undefined") return;
  
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    console.error("LocalStorage yazma hatasi");
  }
}

export function createPlayer(name: string, character: string): PlayerData {
  const state = getGameState();
  const today = getTodayDate();
  
  const player: PlayerData = {
    name,
    character,
    xp: 0,
    gems: 50, // Baslangic gem'i
    badges: [],
    createdAt: new Date().toISOString(),
    lastLoginDate: today,
    loginStreak: 1,
    stats: defaultStats,
    powerUsesLeft: 3,
    hintsLeft: 5,
  };
  
  state.player = player;
  state.daily = createDailyData(1);
  saveGameState(state);
  return player;
}

export function getPlayer(): PlayerData | null {
  return getGameState().player;
}

export function checkAndUpdateDailyLogin(): { isNewDay: boolean; loginStreak: number; bonusReward: number } {
  const state = getGameState();
  if (!state.player) return { isNewDay: false, loginStreak: 0, bonusReward: 0 };
  
  const today = getTodayDate();
  const lastLogin = state.player.lastLoginDate;
  
  if (lastLogin === today) {
    return { isNewDay: false, loginStreak: state.player.loginStreak, bonusReward: 0 };
  }
  
  // Yeni gun!
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split("T")[0];
  
  let newStreak = 1;
  if (lastLogin === yesterdayStr) {
    // Ust uste giris
    newStreak = state.player.loginStreak + 1;
  }
  
  // Bonus hesapla (her 7 gunde ekstra bonus)
  let bonusReward = 10 + (newStreak * 2);
  if (newStreak % 7 === 0) {
    bonusReward += 50; // Haftalik bonus
  }
  
  state.player.lastLoginDate = today;
  state.player.loginStreak = newStreak;
  state.player.gems += bonusReward;
  state.daily = createDailyData(newStreak);
  
  saveGameState(state);
  
  return { isNewDay: true, loginStreak: newStreak, bonusReward };
}

export function addXP(amount: number): { newXP: number; levelUp: boolean; newLevel: number } {
  const state = getGameState();
  if (!state.player) return { newXP: 0, levelUp: false, newLevel: 1 };
  
  const oldLevel = getLevelFromXP(state.player.xp);
  state.player.xp += amount;
  const newLevel = getLevelFromXP(state.player.xp);
  
  // Seviye atladiysa gem ver
  if (newLevel > oldLevel) {
    state.player.gems += (newLevel - oldLevel) * 10;
  }
  
  saveGameState(state);
  
  return {
    newXP: state.player.xp,
    levelUp: newLevel > oldLevel,
    newLevel,
  };
}

export function addGems(amount: number): void {
  const state = getGameState();
  if (state.player) {
    state.player.gems += amount;
    saveGameState(state);
  }
}

export function useGems(amount: number): boolean {
  const state = getGameState();
  if (state.player && state.player.gems >= amount) {
    state.player.gems -= amount;
    saveGameState(state);
    return true;
  }
  return false;
}

export function useHint(): boolean {
  const state = getGameState();
  if (state.player && state.player.hintsLeft > 0) {
    state.player.hintsLeft -= 1;
    saveGameState(state);
    return true;
  }
  return false;
}

export function addHints(amount: number): void {
  const state = getGameState();
  if (state.player) {
    state.player.hintsLeft += amount;
    saveGameState(state);
  }
}

export function usePower(): boolean {
  const state = getGameState();
  if (state.player && state.player.powerUsesLeft > 0) {
    state.player.powerUsesLeft -= 1;
    saveGameState(state);
    return true;
  }
  return false;
}

export function addBadge(badgeId: string): boolean {
  const state = getGameState();
  if (state.player && !state.player.badges.includes(badgeId)) {
    state.player.badges.push(badgeId);
    state.player.gems += 25; // Rozet odulu
    saveGameState(state);
    return true;
  }
  return false;
}

export function updateStats(correct: boolean, streak: number): void {
  const state = getGameState();
  if (!state.player) return;
  
  state.player.stats.totalQuestions += 1;
  if (correct) {
    state.player.stats.totalCorrect += 1;
  } else {
    state.player.stats.totalWrong += 1;
  }
  
  if (streak > state.player.stats.bestStreak) {
    state.player.stats.bestStreak = streak;
  }
  
  saveGameState(state);
}

export function updateSpeedModeHighScore(score: number): void {
  const state = getGameState();
  if (state.player && score > state.player.stats.speedModeHighScore) {
    state.player.stats.speedModeHighScore = score;
    saveGameState(state);
  }
}

export function updateSurvivalModeHighScore(score: number): void {
  const state = getGameState();
  if (state.player && score > state.player.stats.survivalModeHighScore) {
    state.player.stats.survivalModeHighScore = score;
    saveGameState(state);
  }
}

export function incrementBossesDefeated(): void {
  const state = getGameState();
  if (state.player) {
    state.player.stats.bossesDefeated += 1;
    saveGameState(state);
  }
}

export function getTopicProgress(worldId: string, topicId: string): TopicProgress {
  const state = getGameState();
  return state.progress[worldId]?.[topicId] || {
    completed: 0,
    correct: 0,
    wrong: 0,
    bestStreak: 0,
  };
}

export function updateTopicProgress(
  worldId: string,
  topicId: string,
  correct: boolean,
  currentStreak: number
): void {
  const state = getGameState();
  
  if (!state.progress[worldId]) {
    state.progress[worldId] = {};
  }
  
  if (!state.progress[worldId][topicId]) {
    state.progress[worldId][topicId] = {
      completed: 0,
      correct: 0,
      wrong: 0,
      bestStreak: 0,
    };
  }
  
  const progress = state.progress[worldId][topicId];
  progress.completed += 1;
  progress.lastPlayed = new Date().toISOString();
  
  if (correct) {
    progress.correct += 1;
  } else {
    progress.wrong += 1;
  }
  
  if (currentStreak > progress.bestStreak) {
    progress.bestStreak = currentStreak;
  }
  
  // Gunluk ilerleme guncelle
  if (state.daily?.date === getTodayDate()) {
    state.daily.questionsAnswered += 1;
    if (correct) {
      state.daily.correctAnswers += 1;
    }
    if (currentStreak > state.daily.bestStreak) {
      state.daily.bestStreak = currentStreak;
    }
    if (!state.daily.worldsPlayed.includes(worldId)) {
      state.daily.worldsPlayed.push(worldId);
    }
    
    // Challenge'lari guncelle
    updateDailyChallenges(state);
  }
  
  saveGameState(state);
}

function updateDailyChallenges(state: GameState): void {
  if (!state.daily) return;
  
  state.daily.challenges = state.daily.challenges.map((challenge) => {
    if (challenge.completed) return challenge;
    
    let current = 0;
    const config = dailyChallenges.find((c) => c.id === challenge.id);
    if (!config) return challenge;
    
    switch (config.type) {
      case "questions":
        current = state.daily!.questionsAnswered;
        break;
      case "correct":
        current = state.daily!.correctAnswers;
        break;
      case "streak":
        current = state.daily!.bestStreak;
        break;
      case "worlds":
        current = state.daily!.worldsPlayed.length;
        break;
    }
    
    return {
      ...challenge,
      current,
      completed: current >= config.requirement,
    };
  });
}

export function claimDailyReward(challengeId: string): number {
  const state = getGameState();
  if (!state.daily || !state.player) return 0;
  
  const challenge = state.daily.challenges.find((c) => c.id === challengeId);
  const config = dailyChallenges.find((c) => c.id === challengeId);
  
  if (!challenge || !config || !challenge.completed || challenge.claimedReward) {
    return 0;
  }
  
  challenge.claimedReward = true;
  state.player.gems += config.reward;
  saveGameState(state);
  
  return config.reward;
}

export function getDailyData(): DailyData | null {
  const state = getGameState();
  if (state.daily?.date === getTodayDate()) {
    return state.daily;
  }
  return null;
}

export function getWorldProgress(worldId: string): WorldProgress {
  const state = getGameState();
  return state.progress[worldId] || {};
}

export function calculateWorldCompletion(worldId: string, totalTopics: number): number {
  const worldProgress = getWorldProgress(worldId);
  const topicIds = Object.keys(worldProgress);
  
  if (topicIds.length === 0) return 0;
  
  let totalCompleted = 0;
  topicIds.forEach((topicId) => {
    const progress = worldProgress[topicId];
    if (progress.completed >= 10) {
      totalCompleted += 1;
    } else {
      totalCompleted += progress.completed / 10;
    }
  });
  
  return Math.round((totalCompleted / totalTopics) * 100);
}

export function getLeaderboard(): LeaderboardEntry[] {
  const state = getGameState();
  return state.leaderboard.sort((a, b) => b.score - a.score).slice(0, 20);
}

export function addToLeaderboard(entry: Omit<LeaderboardEntry, "date">): void {
  const state = getGameState();
  state.leaderboard.push({
    ...entry,
    date: new Date().toISOString(),
  });
  state.leaderboard = state.leaderboard
    .sort((a, b) => b.score - a.score)
    .slice(0, 100);
  saveGameState(state);
}

export function getSettings(): Settings {
  return getGameState().settings;
}

export function updateSettings(newSettings: Partial<Settings>): void {
  const state = getGameState();
  state.settings = { ...state.settings, ...newSettings };
  saveGameState(state);
}

export function resetGame(): void {
  if (typeof window === "undefined") return;
  localStorage.removeItem(STORAGE_KEY);
}

export function getTotalScore(): number {
  const player = getPlayer();
  return player?.xp || 0;
}
