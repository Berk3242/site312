// 7. Sinif Soru Ureticileri

import {
  Question,
  randomInt,
  createQuestion,
  generateWrongAnswers,
  simplifyFraction,
  formatDecimal,
} from "./generator";

// Rasyonel Sayilar
export function generateRasyonelSayilarQuestion(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // Rasyonel sayi toplama
    const num1 = randomInt(-5, 5);
    const denom1 = randomInt(2, 6);
    const num2 = randomInt(-5, 5);
    const denom2 = denom1; // Ayni payda
    
    const resultNum = num1 + num2;
    const [sNum, sDenom] = simplifyFraction(resultNum, denom1);
    
    const answer = sDenom === 1 ? `${sNum}` : `${sNum}/${sDenom}`;
    const text = `${num1}/${denom1} + ${num2 >= 0 ? "" : "("}${num2}${num2 >= 0 ? "" : ")"}/${denom2} = ?`;
    
    const wrongs = [
      `${resultNum + 1}/${denom1}`,
      `${resultNum - 1}/${denom1}`,
      `${num1 - num2}/${denom1}`,
    ];
    
    return createQuestion(text, answer, wrongs, "rasyonel-sayilar", 7, 2);
  } else if (type === 2) {
    // Rasyonel sayi carpma
    const num1 = randomInt(-4, 4);
    if (num1 === 0) return generateRasyonelSayilarQuestion();
    const denom1 = randomInt(2, 5);
    const num2 = randomInt(-4, 4);
    if (num2 === 0) return generateRasyonelSayilarQuestion();
    const denom2 = randomInt(2, 5);
    
    const resultNum = num1 * num2;
    const resultDenom = denom1 * denom2;
    const [sNum, sDenom] = simplifyFraction(resultNum, resultDenom);
    
    const answer = sDenom === 1 ? `${sNum}` : `${sNum}/${sDenom}`;
    const text = `(${num1}/${denom1}) x (${num2}/${denom2}) = ?`;
    
    const wrongs = [
      `${-sNum}/${sDenom}`,
      `${sNum + 1}/${sDenom}`,
      `${resultDenom}/${resultNum}`,
    ];
    
    return createQuestion(text, answer, wrongs, "rasyonel-sayilar", 7, 2);
  } else {
    // Rasyonel sayi siralama
    const nums = [randomInt(-10, 10) / 5, randomInt(-10, 10) / 5, randomInt(-10, 10) / 5];
    const sorted = [...nums].sort((a, b) => a - b);
    
    const text = `${nums.map(n => formatDecimal(n, 1)).join(", ")} sayilarini kucukten buyuge siralayiniz.`;
    const answer = sorted.map(n => formatDecimal(n, 1)).join(" < ");
    
    const wrongs = [
      sorted.reverse().map(n => formatDecimal(n, 1)).join(" < "),
      nums.map(n => formatDecimal(n, 1)).join(" < "),
      [nums[1], nums[0], nums[2]].map(n => formatDecimal(n, 1)).join(" < "),
    ];
    
    return createQuestion(text, answer, wrongs, "rasyonel-sayilar", 7, 2);
  }
}

// Cebirsel Ifadeler
export function generateCebirselIfadelerQuestion(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // Benzer terimleri toplama
    const a = randomInt(2, 8);
    const b = randomInt(2, 8);
    const result = a + b;
    
    const text = `${a}x + ${b}x = ?`;
    const wrongs = [`${a * b}x`, `${a + b}x²`, `${Math.abs(a - b)}x`];
    
    return createQuestion(text, `${result}x`, wrongs, "cebirsel-ifadeler", 7, 1);
  } else if (type === 2) {
    // Parantez acma
    const a = randomInt(2, 5);
    const b = randomInt(1, 6);
    const c = randomInt(1, 6);
    
    const text = `${a}(x + ${b}) + ${c} ifadesini sadelestirin.`;
    const answer = `${a}x + ${a * b + c}`;
    
    const wrongs = [
      `${a}x + ${b + c}`,
      `${a + 1}x + ${a * b}`,
      `${a}x + ${b}`,
    ];
    
    return createQuestion(text, answer, wrongs, "cebirsel-ifadeler", 7, 2);
  } else {
    // Carpma (x ile)
    const a = randomInt(2, 6);
    const b = randomInt(2, 6);
    
    const text = `${a}x . ${b}x = ?`;
    const answer = `${a * b}x²`;
    
    const wrongs = [
      `${a + b}x`,
      `${a * b}x`,
      `${a + b}x²`,
    ];
    
    return createQuestion(text, answer, wrongs, "cebirsel-ifadeler", 7, 2);
  }
}

// Esitsizlikler
export function generateEsitsizliklerQuestion(): Question {
  const type = randomInt(1, 2);
  
  if (type === 1) {
    // Basit esitsizlik
    const a = randomInt(2, 6);
    const b = randomInt(5, 20);
    const result = Math.floor(b / a);
    
    const text = `${a}x < ${b} esitsizligini saglayan en buyuk tam sayi kactir?`;
    const wrongs = generateWrongAnswers(result, 3, 1, 3);
    
    return createQuestion(
      text,
      result.toString(),
      wrongs.map(w => w.toString()),
      "esitsizlikler",
      7,
      2
    );
  } else {
    // Esitsizlik yonu
    const a = randomInt(2, 8);
    const b = randomInt(10, 30);
    
    const text = `${a}x > ${b} esitsizligini cozelim. x hangi degerlerden buyuktur?`;
    const result = b / a;
    const answer = Number.isInteger(result) ? result.toString() : formatDecimal(result, 1);
    
    const wrongs = [
      formatDecimal(result + 1, 1),
      formatDecimal(result - 1, 1),
      formatDecimal(a * b / 10, 1),
    ];
    
    return createQuestion(text, answer, wrongs, "esitsizlikler", 7, 2);
  }
}

// Dogrusal Denklemler
export function generateDogrusalDenklemlerQuestion(): Question {
  const type = randomInt(1, 2);
  
  if (type === 1) {
    // ax + b = cx + d
    const x = randomInt(1, 8);
    const a = randomInt(3, 8);
    const c = randomInt(1, a - 1);
    const b = randomInt(1, 15);
    const d = (a - c) * x + b;
    
    const text = `${a}x + ${b} = ${c}x + ${d} ise x = ?`;
    const wrongs = generateWrongAnswers(x, 3, 1, 4);
    
    return createQuestion(
      text,
      x.toString(),
      wrongs.map(w => w.toString()),
      "dogrusal-denklemler",
      7,
      2
    );
  } else {
    // Parantezli denklem
    const x = randomInt(2, 8);
    const a = randomInt(2, 5);
    const b = randomInt(1, 6);
    const result = a * (x + b);
    
    const text = `${a}(x + ${b}) = ${result} ise x = ?`;
    const wrongs = generateWrongAnswers(x, 3, 1, 4);
    
    return createQuestion(
      text,
      x.toString(),
      wrongs.map(w => w.toString()),
      "dogrusal-denklemler",
      7,
      2
    );
  }
}

// Ucgenler
export function generateUcgenlerQuestion(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // Ucgen alani
    const base = randomInt(4, 12);
    const height = randomInt(3, 10);
    const result = (base * height) / 2;
    
    const text = `Tabani ${base} cm, yuksekligi ${height} cm olan ucgenin alani kac cm² dir?`;
    const wrongs = generateWrongAnswers(result, 3, 2, 10);
    
    return createQuestion(
      text,
      `${result} cm²`,
      wrongs.map(w => `${w} cm²`),
      "ucgenler",
      7,
      1
    );
  } else if (type === 2) {
    // Ucgen aci toplami
    const angle1 = randomInt(30, 80);
    const angle2 = randomInt(30, 80);
    const result = 180 - angle1 - angle2;
    
    const text = `Bir ucgenin iki acisi ${angle1}° ve ${angle2}° ise ucuncu aci kac derecedir?`;
    const wrongs = generateWrongAnswers(result, 3, 5, 20);
    
    return createQuestion(
      text,
      `${result}°`,
      wrongs.map(w => `${Math.abs(w)}°`),
      "ucgenler",
      7,
      1
    );
  } else {
    // Ucgen cesitleri
    const types = [
      { angles: [60, 60, 60], name: "Eskenar ucgen" },
      { angles: [45, 45, 90], name: "Ikizkenar dik ucgen" },
      { angles: [30, 60, 90], name: "30-60-90 ucgeni" },
    ];
    
    const selected = types[randomInt(0, 2)];
    const text = `Acilari ${selected.angles.join("°, ")}° olan ucgen ne tur bir ucgendir?`;
    
    const wrongs = types.filter(t => t.name !== selected.name).map(t => t.name);
    wrongs.push("Cesitkenar ucgen");
    
    return createQuestion(text, selected.name, wrongs.slice(0, 3), "ucgenler", 7, 2);
  }
}

// Cember ve Daire
export function generateCemberDaireQuestion(): Question {
  const type = randomInt(1, 2);
  const r = randomInt(3, 10);
  
  if (type === 1) {
    // Yay uzunlugu
    const angle = [60, 90, 120, 180][randomInt(0, 3)];
    const result = (2 * 3.14 * r * angle) / 360;
    
    const text = `Yaricapi ${r} cm olan cemberde ${angle}° lik yay uzunlugu kac cm dir? (pi = 3,14)`;
    
    const wrongs = [
      formatDecimal(result + 3.14),
      formatDecimal(result * 2),
      formatDecimal(3.14 * r),
    ];
    
    return createQuestion(
      text,
      formatDecimal(result),
      wrongs,
      "cember-daire",
      7,
      3
    );
  } else {
    // Daire dilimi alani
    const angle = [60, 90, 120, 180][randomInt(0, 3)];
    const result = (3.14 * r * r * angle) / 360;
    
    const text = `Yaricapi ${r} cm olan dairede ${angle}° lik dilimin alani kac cm² dir? (pi = 3,14)`;
    
    const wrongs = [
      formatDecimal(result + 10),
      formatDecimal(result * 2),
      formatDecimal(3.14 * r * r),
    ];
    
    return createQuestion(
      text,
      formatDecimal(result),
      wrongs,
      "cember-daire",
      7,
      3
    );
  }
}

// Olasilik
export function generateOlasilik7Question(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // Zar olasiligi
    const target = randomInt(1, 6);
    const text = `Bir zar atildiginda ${target} gelme olasiligi nedir?`;
    
    return createQuestion(
      text,
      "1/6",
      ["1/3", "1/2", "2/6"],
      "olasilik-7",
      7,
      1
    );
  } else if (type === 2) {
    // Para olasiligi
    const text = `Bir para 2 kez atildiginda en az bir yazi gelme olasiligi nedir?`;
    
    return createQuestion(
      text,
      "3/4",
      ["1/2", "1/4", "2/3"],
      "olasilik-7",
      7,
      2
    );
  } else {
    // Top cekme
    const red = randomInt(2, 5);
    const blue = randomInt(2, 5);
    const total = red + blue;
    const [sNum, sDenom] = simplifyFraction(red, total);
    
    const text = `Bir torbada ${red} kirmizi ve ${blue} mavi top vardir. Rastgele cekilen bir topun kirmizi olma olasiligi nedir?`;
    const answer = `${sNum}/${sDenom}`;
    
    const wrongs = [
      `${blue}/${total}`,
      `${red}/${blue}`,
      `1/${total}`,
    ];
    
    return createQuestion(text, answer, wrongs, "olasilik-7", 7, 2);
  }
}

// 7. sinif soru uretici haritasi
export const grade7Generators: { [topicId: string]: () => Question } = {
  "rasyonel-sayilar": generateRasyonelSayilarQuestion,
  "cebirsel-ifadeler": generateCebirselIfadelerQuestion,
  "esitsizlikler": generateEsitsizliklerQuestion,
  "dogrusal-denklemler": generateDogrusalDenklemlerQuestion,
  "ucgenler": generateUcgenlerQuestion,
  "cember-daire": generateCemberDaireQuestion,
  "olasilik-7": generateOlasilik7Question,
};
