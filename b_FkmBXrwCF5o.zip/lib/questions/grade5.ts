// 5. Sinif Soru Ureticileri

import {
  Question,
  randomInt,
  createQuestion,
  generateWrongAnswers,
  simplifyFraction,
  formatNumber,
} from "./generator";

// Dogal Sayilar
export function generateDogalSayilarQuestion(): Question {
  const operations = ["+", "-", "*", "/"];
  const op = operations[randomInt(0, 3)];
  
  let a: number, b: number, result: number, text: string;
  
  switch (op) {
    case "+":
      a = randomInt(100, 9999);
      b = randomInt(100, 9999);
      result = a + b;
      text = `${formatNumber(a)} + ${formatNumber(b)} = ?`;
      break;
    case "-":
      a = randomInt(500, 9999);
      b = randomInt(100, a - 100);
      result = a - b;
      text = `${formatNumber(a)} - ${formatNumber(b)} = ?`;
      break;
    case "*":
      a = randomInt(10, 99);
      b = randomInt(10, 99);
      result = a * b;
      text = `${a} x ${b} = ?`;
      break;
    default: // division
      b = randomInt(2, 12);
      result = randomInt(10, 99);
      a = b * result;
      text = `${formatNumber(a)} / ${b} = ?`;
      break;
  }
  
  const wrongs = generateWrongAnswers(result, 3, 1, Math.max(10, Math.floor(result * 0.1)));
  
  return createQuestion(
    text,
    formatNumber(result),
    wrongs.map(formatNumber),
    "dogal-sayilar",
    5,
    op === "*" || op === "/" ? 2 : 1
  );
}

// Kesirler
export function generateKesirler5Question(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // Kesir karsilastirma
    const denom = randomInt(3, 10);
    const num1 = randomInt(1, denom - 1);
    const num2 = randomInt(1, denom - 1);
    
    if (num1 === num2) {
      return generateKesirler5Question();
    }
    
    const answer = num1 > num2 ? ">" : num1 < num2 ? "<" : "=";
    const text = `${num1}/${denom} __ ${num2}/${denom} ifadesinde bosluga hangi isaret gelmeli?`;
    
    return createQuestion(
      text,
      answer,
      ["<", ">", "="].filter(x => x !== answer),
      "kesirler-5",
      5,
      1
    );
  } else if (type === 2) {
    // Kesir toplama (ayni paydali)
    const denom = randomInt(5, 12);
    const num1 = randomInt(1, denom - 2);
    const num2 = randomInt(1, denom - num1 - 1);
    const resultNum = num1 + num2;
    
    const [sNum, sDenom] = simplifyFraction(resultNum, denom);
    const answer = sDenom === 1 ? `${sNum}` : `${sNum}/${sDenom}`;
    
    const text = `${num1}/${denom} + ${num2}/${denom} = ?`;
    
    const wrongs = [
      `${num1 + num2}/${denom * 2}`,
      `${num1 + num2 + 1}/${denom}`,
      `${Math.abs(num1 - num2)}/${denom}`,
    ];
    
    return createQuestion(text, answer, wrongs, "kesirler-5", 5, 1);
  } else {
    // Kesir cikarma
    const denom = randomInt(5, 12);
    const num1 = randomInt(3, denom - 1);
    const num2 = randomInt(1, num1 - 1);
    const resultNum = num1 - num2;
    
    const [sNum, sDenom] = simplifyFraction(resultNum, denom);
    const answer = sDenom === 1 ? `${sNum}` : `${sNum}/${sDenom}`;
    
    const text = `${num1}/${denom} - ${num2}/${denom} = ?`;
    
    const wrongs = [
      `${num1 - num2 + 1}/${denom}`,
      `${num1 + num2}/${denom}`,
      `${Math.max(1, num1 - num2 - 1)}/${denom}`,
    ];
    
    return createQuestion(text, answer, wrongs, "kesirler-5", 5, 1);
  }
}

// Ondalik Gosterim
export function generateOndalikGosterimQuestion(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // Ondalik toplama
    const a = randomInt(10, 99) / 10;
    const b = randomInt(10, 99) / 10;
    const result = +(a + b).toFixed(1);
    
    const text = `${a.toFixed(1)} + ${b.toFixed(1)} = ?`;
    const wrongs = generateWrongAnswers(result * 10, 3, 1, 5).map(w => (w / 10).toFixed(1));
    
    return createQuestion(text, result.toFixed(1), wrongs, "ondalik-gosterim", 5, 1);
  } else if (type === 2) {
    // Ondalik cikarma
    const a = randomInt(50, 99) / 10;
    const b = randomInt(10, Math.floor(a * 10) - 10) / 10;
    const result = +(a - b).toFixed(1);
    
    const text = `${a.toFixed(1)} - ${b.toFixed(1)} = ?`;
    const wrongs = generateWrongAnswers(result * 10, 3, 1, 5).map(w => (w / 10).toFixed(1));
    
    return createQuestion(text, result.toFixed(1), wrongs, "ondalik-gosterim", 5, 2);
  } else {
    // Kesirden ondaliga
    const denom = [2, 4, 5, 10][randomInt(0, 3)];
    const num = randomInt(1, denom - 1);
    const result = num / denom;
    
    const text = `${num}/${denom} kesrinin ondalik gosterimi nedir?`;
    
    const wrongs = [
      (result + 0.1).toFixed(2),
      (result - 0.1 > 0 ? result - 0.1 : result + 0.2).toFixed(2),
      (result * 2).toFixed(2),
    ];
    
    return createQuestion(text, result.toFixed(2), wrongs, "ondalik-gosterim", 5, 2);
  }
}

// Yuzde Hesaplama
export function generateYuzdeHesaplamaQuestion(): Question {
  const type = randomInt(1, 2);
  
  if (type === 1) {
    // Bir sayinin yuzdesi
    const percent = [10, 20, 25, 50, 75][randomInt(0, 4)];
    const number = randomInt(4, 20) * (100 / percent);
    const result = (number * percent) / 100;
    
    const text = `${formatNumber(number)} sayisinin %${percent}'${percent === 50 ? "si" : percent === 25 || percent === 75 ? "i" : "i"} kactir?`;
    const wrongs = generateWrongAnswers(result, 3, 1, Math.max(5, Math.floor(result * 0.2)));
    
    return createQuestion(
      text,
      formatNumber(result),
      wrongs.map(formatNumber),
      "yuzde-hesaplama",
      5,
      1
    );
  } else {
    // Yuzde bulma
    const whole = [20, 40, 50, 100, 200][randomInt(0, 4)];
    const part = randomInt(1, 4) * (whole / 4);
    const result = (part / whole) * 100;
    
    const text = `${formatNumber(part)}, ${formatNumber(whole)} sayisinin yuzde kaci kadardir?`;
    const wrongs = generateWrongAnswers(result, 3, 5, 25);
    
    return createQuestion(
      text,
      `%${result}`,
      wrongs.map(w => `%${w}`),
      "yuzde-hesaplama",
      5,
      2
    );
  }
}

// Alan ve Cevre
export function generateAlanCevreQuestion(): Question {
  const type = randomInt(1, 4);
  
  if (type === 1) {
    // Dikdortgen alan
    const a = randomInt(3, 15);
    const b = randomInt(3, 15);
    const result = a * b;
    
    const text = `Uzun kenari ${a} cm, kisa kenari ${b} cm olan dikdortgenin alani kac cm² dir?`;
    const wrongs = generateWrongAnswers(result, 3, 2, 15);
    
    return createQuestion(
      text,
      `${result} cm²`,
      wrongs.map(w => `${w} cm²`),
      "alan-cevre",
      5,
      1
    );
  } else if (type === 2) {
    // Dikdortgen cevre
    const a = randomInt(3, 15);
    const b = randomInt(3, 15);
    const result = 2 * (a + b);
    
    const text = `Uzun kenari ${a} cm, kisa kenari ${b} cm olan dikdortgenin cevresi kac cm dir?`;
    const wrongs = generateWrongAnswers(result, 3, 2, 10);
    
    return createQuestion(
      text,
      `${result} cm`,
      wrongs.map(w => `${w} cm`),
      "alan-cevre",
      5,
      1
    );
  } else if (type === 3) {
    // Kare alan
    const a = randomInt(3, 12);
    const result = a * a;
    
    const text = `Bir kenari ${a} cm olan karenin alani kac cm² dir?`;
    const wrongs = generateWrongAnswers(result, 3, 2, 15);
    
    return createQuestion(
      text,
      `${result} cm²`,
      wrongs.map(w => `${w} cm²`),
      "alan-cevre",
      5,
      1
    );
  } else {
    // Kare cevre
    const a = randomInt(3, 15);
    const result = 4 * a;
    
    const text = `Bir kenari ${a} cm olan karenin cevresi kac cm dir?`;
    const wrongs = generateWrongAnswers(result, 3, 2, 8);
    
    return createQuestion(
      text,
      `${result} cm`,
      wrongs.map(w => `${w} cm`),
      "alan-cevre",
      5,
      1
    );
  }
}

// Acilar
export function generateAcilarQuestion(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // Aci turu belirleme
    const angle = randomInt(10, 170);
    let answer: string;
    
    if (angle < 90) answer = "Dar aci";
    else if (angle === 90) answer = "Dik aci";
    else answer = "Genis aci";
    
    const text = `${angle} derece olcusundeki aci ne tur bir acidir?`;
    const wrongs = ["Dar aci", "Dik aci", "Genis aci"].filter(x => x !== answer);
    
    return createQuestion(text, answer, wrongs, "acilar", 5, 1);
  } else if (type === 2) {
    // Tamamlayan aci (90 dereceye)
    const angle = randomInt(10, 80);
    const result = 90 - angle;
    
    const text = `${angle} derecenin tamamlayani kac derecedir?`;
    const wrongs = generateWrongAnswers(result, 3, 5, 20);
    
    return createQuestion(
      text,
      `${result}°`,
      wrongs.map(w => `${Math.abs(w)}°`),
      "acilar",
      5,
      2
    );
  } else {
    // Butunler aci (180 dereceye)
    const angle = randomInt(20, 160);
    const result = 180 - angle;
    
    const text = `${angle} derecenin butunleri kac derecedir?`;
    const wrongs = generateWrongAnswers(result, 3, 10, 30);
    
    return createQuestion(
      text,
      `${result}°`,
      wrongs.map(w => `${Math.abs(w)}°`),
      "acilar",
      5,
      2
    );
  }
}

// Cokgenler
export function generateCokgenlerQuestion(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // Cokgen isimleri
    const polygons = [
      { sides: 3, name: "Ucgen" },
      { sides: 4, name: "Dortgen" },
      { sides: 5, name: "Besgen" },
      { sides: 6, name: "Altigen" },
      { sides: 7, name: "Yedigen" },
      { sides: 8, name: "Sekizgen" },
    ];
    
    const polygon = polygons[randomInt(0, 5)];
    const text = `${polygon.sides} kenari olan cokgenin adi nedir?`;
    const wrongs = polygons.filter(p => p.name !== polygon.name).slice(0, 3).map(p => p.name);
    
    return createQuestion(text, polygon.name, wrongs, "cokgenler", 5, 1);
  } else if (type === 2) {
    // Ic acilar toplami
    const sides = randomInt(3, 8);
    const result = (sides - 2) * 180;
    const names = ["", "", "", "ucgenin", "dortgenin", "besgenin", "altigenin", "yedigenin", "sekizgenin"];
    
    const text = `Bir ${names[sides]} ic acilar toplami kac derecedir?`;
    const wrongs = generateWrongAnswers(result, 3, 90, 180);
    
    return createQuestion(
      text,
      `${result}°`,
      wrongs.map(w => `${Math.abs(w)}°`),
      "cokgenler",
      5,
      2
    );
  } else {
    // Diyagonal sayisi
    const sides = randomInt(4, 8);
    const result = (sides * (sides - 3)) / 2;
    const names = ["", "", "", "", "dortgenin", "besgenin", "altigenin", "yedigenin", "sekizgenin"];
    
    const text = `Bir ${names[sides]} kac tane kosegeni vardir?`;
    const wrongs = generateWrongAnswers(result, 3, 1, 5);
    
    return createQuestion(
      text,
      `${result}`,
      wrongs.map(w => `${Math.abs(w)}`),
      "cokgenler",
      5,
      3
    );
  }
}

// 5. sinif soru uretici haritasi
export const grade5Generators: { [topicId: string]: () => Question } = {
  "dogal-sayilar": generateDogalSayilarQuestion,
  "kesirler-5": generateKesirler5Question,
  "ondalik-gosterim": generateOndalikGosterimQuestion,
  "yuzde-hesaplama": generateYuzdeHesaplamaQuestion,
  "alan-cevre": generateAlanCevreQuestion,
  "acilar": generateAcilarQuestion,
  "cokgenler": generateCokgenlerQuestion,
};
