// Ana Soru Uretici

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctIndex: number;
  difficulty: 1 | 2 | 3;
  topic: string;
  grade: 5 | 6 | 7 | 8;
}

// Yardimci fonksiyonlar
export function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

export function generateWrongAnswers(
  correct: number,
  count: number = 3,
  minDiff: number = 1,
  maxDiff: number = 10
): number[] {
  const wrongs: number[] = [];
  const attempts = 0;
  
  while (wrongs.length < count && attempts < 100) {
    const diff = randomInt(minDiff, maxDiff) * (Math.random() > 0.5 ? 1 : -1);
    const wrong = correct + diff;
    
    if (wrong !== correct && !wrongs.includes(wrong) && wrong >= 0) {
      wrongs.push(wrong);
    }
  }
  
  // Yeterli yanlis cevap uretilemezse rastgele degerler ekle
  while (wrongs.length < count) {
    const wrong = correct + randomInt(1, 20) * (wrongs.length % 2 === 0 ? 1 : -1);
    if (!wrongs.includes(wrong) && wrong !== correct) {
      wrongs.push(wrong);
    }
  }
  
  return wrongs;
}

export function createQuestion(
  text: string,
  correctAnswer: string,
  wrongAnswers: string[],
  topic: string,
  grade: 5 | 6 | 7 | 8,
  difficulty: 1 | 2 | 3 = 1
): Question {
  const allOptions = [correctAnswer, ...wrongAnswers];
  const shuffledOptions = shuffleArray(allOptions);
  const correctIndex = shuffledOptions.indexOf(correctAnswer);
  
  return {
    id: generateId(),
    text,
    options: shuffledOptions,
    correctIndex,
    difficulty,
    topic,
    grade,
  };
}

// GCD (En buyuk ortak bolen) hesaplama
export function gcd(a: number, b: number): number {
  a = Math.abs(a);
  b = Math.abs(b);
  while (b) {
    const t = b;
    b = a % b;
    a = t;
  }
  return a;
}

// Kesir sadelelestirme
export function simplifyFraction(numerator: number, denominator: number): [number, number] {
  const d = gcd(numerator, denominator);
  return [numerator / d, denominator / d];
}

// Sayi formatlama (buyuk sayilar icin)
export function formatNumber(num: number): string {
  return num.toLocaleString("tr-TR");
}

// Ondalik sayi formatlama
export function formatDecimal(num: number, decimals: number = 2): string {
  return num.toLocaleString("tr-TR", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}
