// Tum soru ureticileri birlestir

import { Question } from "./generator";
import { grade5Generators } from "./grade5";
import { grade6Generators } from "./grade6";
import { grade7Generators } from "./grade7";
import { grade8Generators } from "./grade8";

export type { Question };

// Tum ureticiler
const allGenerators: { [topicId: string]: () => Question } = {
  ...grade5Generators,
  ...grade6Generators,
  ...grade7Generators,
  ...grade8Generators,
};

// Belirli bir konu icin soru uret
export function generateQuestion(topicId: string): Question {
  const generator = allGenerators[topicId];
  if (!generator) {
    throw new Error(`Konu bulunamadi: ${topicId}`);
  }
  return generator();
}

// Belirli bir konu icin birden fazla soru uret
export function generateQuestions(topicId: string, count: number): Question[] {
  const questions: Question[] = [];
  for (let i = 0; i < count; i++) {
    questions.push(generateQuestion(topicId));
  }
  return questions;
}

// Tum konular icin soru uretici var mi kontrol et
export function hasGenerator(topicId: string): boolean {
  return topicId in allGenerators;
}
