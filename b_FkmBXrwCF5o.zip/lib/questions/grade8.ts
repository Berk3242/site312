// 8. Sinif Soru Ureticileri

import {
  Question,
  randomInt,
  createQuestion,
  generateWrongAnswers,
  simplifyFraction,
} from "./generator";

// Uslu Sayilar
export function generateUsluSayilarQuestion(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // Basit us hesaplama
    const base = randomInt(2, 5);
    const exp = randomInt(2, 4);
    const result = Math.pow(base, exp);
    
    const text = `${base}^${exp} = ?`;
    const wrongs = generateWrongAnswers(result, 3, 2, Math.floor(result * 0.3));
    
    return createQuestion(
      text,
      result.toString(),
      wrongs.map(w => w.toString()),
      "uslu-sayilar",
      8,
      1
    );
  } else if (type === 2) {
    // Us carpma
    const base = randomInt(2, 4);
    const exp1 = randomInt(2, 4);
    const exp2 = randomInt(2, 4);
    const resultExp = exp1 + exp2;
    
    const text = `${base}^${exp1} . ${base}^${exp2} = ${base}^?`;
    const wrongs = [exp1 * exp2, Math.abs(exp1 - exp2), resultExp + 1];
    
    return createQuestion(
      text,
      resultExp.toString(),
      wrongs.map(w => w.toString()),
      "uslu-sayilar",
      8,
      2
    );
  } else {
    // Us bolme
    const base = randomInt(2, 5);
    const exp1 = randomInt(4, 7);
    const exp2 = randomInt(1, exp1 - 1);
    const resultExp = exp1 - exp2;
    
    const text = `${base}^${exp1} / ${base}^${exp2} = ${base}^?`;
    const wrongs = [exp1 + exp2, exp1 * exp2, resultExp + 1];
    
    return createQuestion(
      text,
      resultExp.toString(),
      wrongs.map(w => w.toString()),
      "uslu-sayilar",
      8,
      2
    );
  }
}

// Koklu Sayilar
export function generateKokluSayilarQuestion(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // Tam kare koku
    const root = randomInt(2, 12);
    const number = root * root;
    
    const text = `√${number} = ?`;
    const wrongs = generateWrongAnswers(root, 3, 1, 3);
    
    return createQuestion(
      text,
      root.toString(),
      wrongs.map(w => w.toString()),
      "koklu-sayilar",
      8,
      1
    );
  } else if (type === 2) {
    // Kok carpma
    const a = randomInt(2, 6);
    const b = randomInt(2, 6);
    const result = a * b;
    
    const text = `√${a * a} . √${b * b} = ?`;
    const wrongs = generateWrongAnswers(result, 3, 1, 5);
    
    return createQuestion(
      text,
      result.toString(),
      wrongs.map(w => w.toString()),
      "koklu-sayilar",
      8,
      2
    );
  } else {
    // Kok sadelelestirme
    const inner = randomInt(2, 5);
    const outer = randomInt(2, 4);
    const number = outer * outer * inner;
    
    const text = `√${number} ifadesini sadelestirin.`;
    const answer = `${outer}√${inner}`;
    
    const wrongs = [
      `${outer + 1}√${inner}`,
      `${outer}√${inner + 1}`,
      `√${number}`,
    ];
    
    return createQuestion(text, answer, wrongs, "koklu-sayilar", 8, 2);
  }
}

// Denklem Sistemleri
export function generateDenklemSistemleriQuestion(): Question {
  // x + y = a, x - y = b sistemleri
  const x = randomInt(2, 10);
  const y = randomInt(1, 8);
  const sum = x + y;
  const diff = x - y;
  
  const type = randomInt(1, 2);
  
  if (type === 1) {
    const text = `x + y = ${sum} ve x - y = ${diff} ise x = ?`;
    const wrongs = generateWrongAnswers(x, 3, 1, 4);
    
    return createQuestion(
      text,
      x.toString(),
      wrongs.map(w => w.toString()),
      "denklem-sistemleri",
      8,
      2
    );
  } else {
    const text = `x + y = ${sum} ve x - y = ${diff} ise y = ?`;
    const wrongs = generateWrongAnswers(y, 3, 1, 4);
    
    return createQuestion(
      text,
      y.toString(),
      wrongs.map(w => w.toString()),
      "denklem-sistemleri",
      8,
      2
    );
  }
}

// Esitsizlik Sistemleri
export function generateEsitsizlikSistemleriQuestion(): Question {
  const a = randomInt(2, 5);
  const b = randomInt(10, 30);
  const c = randomInt(1, 3);
  const d = randomInt(1, 8);
  
  // ax > b ve cx < d
  const lower = Math.ceil(b / a);
  const upper = Math.floor(d / c);
  
  if (lower >= upper) return generateEsitsizlikSistemleriQuestion();
  
  const solutions = [];
  for (let i = lower + 1; i < upper; i++) {
    solutions.push(i);
  }
  
  if (solutions.length === 0) return generateEsitsizlikSistemleriQuestion();
  
  const text = `${a}x > ${b} ve ${c}x < ${d} esitsizlik sistemini saglayan bir tam sayi yazin.`;
  const answer = solutions[0].toString();
  
  const wrongs = [
    (lower - 1).toString(),
    (upper + 1).toString(),
    (lower).toString(),
  ];
  
  return createQuestion(text, answer, wrongs, "esitsizlik-sistemleri", 8, 3);
}

// Ucgende Eslik ve Benzerlik
export function generateUcgenEslikBenzerlikQuestion(): Question {
  const type = randomInt(1, 2);
  
  if (type === 1) {
    // Benzer ucgen kenar orani
    const ratio = randomInt(2, 4);
    const side1 = randomInt(3, 8);
    const side2 = side1 * ratio;
    const other1 = randomInt(4, 10);
    const other2 = other1 * ratio;
    
    const text = `ABC ve DEF ucgenleri benzerdir. AB = ${side1} cm, DE = ${side2} cm ve BC = ${other1} cm ise EF kac cm dir?`;
    const wrongs = generateWrongAnswers(other2, 3, 2, 6);
    
    return createQuestion(
      text,
      `${other2} cm`,
      wrongs.map(w => `${w} cm`),
      "ucgen-eslik-benzerlik",
      8,
      2
    );
  } else {
    // Eslik kosullari
    const conditions = ["KKK", "AKA", "KAK", "KKA"];
    const correct = conditions[randomInt(0, 2)];
    
    const text = `Asagidakilerden hangisi ucgen eslik kosullarindan biri DEGILDIR?`;
    const answer = "KKA";
    
    const wrongs = ["KKK", "AKA", "KAK"];
    
    return createQuestion(text, answer, wrongs, "ucgen-eslik-benzerlik", 8, 2);
  }
}

// Pisagor Teoremi
export function generatePisagorTeremiQuestion(): Question {
  const type = randomInt(1, 3);
  
  // Pisagor ucluleriy
  const triples = [
    [3, 4, 5],
    [5, 12, 13],
    [8, 15, 17],
    [6, 8, 10],
    [9, 12, 15],
  ];
  
  const triple = triples[randomInt(0, 4)];
  
  if (type === 1) {
    // Hipothenus bul
    const text = `Dik ucgenin dik kenarlari ${triple[0]} cm ve ${triple[1]} cm ise hipotenüs kac cm dir?`;
    const wrongs = generateWrongAnswers(triple[2], 3, 1, 4);
    
    return createQuestion(
      text,
      `${triple[2]} cm`,
      wrongs.map(w => `${w} cm`),
      "pisagor-teoremi",
      8,
      2
    );
  } else if (type === 2) {
    // Dik kenar bul
    const text = `Dik ucgenin hipotenusu ${triple[2]} cm, bir dik kenari ${triple[0]} cm ise diger dik kenar kac cm dir?`;
    const wrongs = generateWrongAnswers(triple[1], 3, 1, 4);
    
    return createQuestion(
      text,
      `${triple[1]} cm`,
      wrongs.map(w => `${w} cm`),
      "pisagor-teoremi",
      8,
      2
    );
  } else {
    // Dik ucgen mi?
    const a = randomInt(3, 8);
    const b = randomInt(4, 10);
    const cSquared = a * a + b * b;
    const c = Math.sqrt(cSquared);
    const isRight = Number.isInteger(c);
    
    const text = `Kenarlari ${a} cm, ${b} cm ve ${isRight ? c : c + 1} cm olan ucgen dik ucgen midir?`;
    const answer = isRight ? "Evet" : "Hayir";
    
    return createQuestion(
      text,
      answer,
      [isRight ? "Hayir" : "Evet", "Bilgi yetersiz", "Belirlenemez"],
      "pisagor-teoremi",
      8,
      2
    );
  }
}

// Olasilik (Ileri)
export function generateOlasilik8Question(): Question {
  const type = randomInt(1, 2);
  
  if (type === 1) {
    // Birlesik olasilik (ve)
    const red = randomInt(2, 4);
    const blue = randomInt(2, 4);
    const total = red + blue;
    
    const prob1 = red / total;
    const prob2 = (red - 1) / (total - 1);
    const result = prob1 * prob2;
    
    const [sNum, sDenom] = simplifyFraction(red * (red - 1), total * (total - 1));
    
    const text = `${total} toptan ${red} tanesi kirmizidir. Arka arkaya 2 top cekildiginde (ilk top yerine konmadan) her ikisinin de kirmizi olma olasiligi nedir?`;
    const answer = `${sNum}/${sDenom}`;
    
    const wrongs = [
      `${red}/${total}`,
      `${red * red}/${total * total}`,
      `${red - 1}/${total - 1}`,
    ];
    
    return createQuestion(text, answer, wrongs, "olasilik-8", 8, 3);
  } else {
    // Tamamlayici olasilik
    const total = randomInt(5, 10);
    const favorable = randomInt(1, total - 1);
    const [sNum, sDenom] = simplifyFraction(total - favorable, total);
    
    const text = `Bir olayın olma olasiligi ${favorable}/${total} ise, bu olayin OLMAMA olasiligi nedir?`;
    const answer = `${sNum}/${sDenom}`;
    
    const wrongs = [
      `${favorable}/${total}`,
      `${favorable + 1}/${total}`,
      `1/${total}`,
    ];
    
    return createQuestion(text, answer, wrongs, "olasilik-8", 8, 2);
  }
}

// Fonksiyonlar
export function generateFonksiyonlarQuestion(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // f(x) = ax + b
    const a = randomInt(2, 6);
    const b = randomInt(-5, 10);
    const x = randomInt(1, 8);
    const result = a * x + b;
    
    const bStr = b >= 0 ? `+ ${b}` : `- ${Math.abs(b)}`;
    const text = `f(x) = ${a}x ${bStr} ise f(${x}) = ?`;
    const wrongs = generateWrongAnswers(result, 3, 2, 10);
    
    return createQuestion(
      text,
      result.toString(),
      wrongs.map(w => w.toString()),
      "fonksiyonlar",
      8,
      1
    );
  } else if (type === 2) {
    // f(a) = b ise a = ?
    const a_coef = randomInt(2, 5);
    const b_const = randomInt(1, 8);
    const x = randomInt(2, 8);
    const result = a_coef * x + b_const;
    
    const text = `f(x) = ${a_coef}x + ${b_const} fonksiyonunda f(a) = ${result} ise a = ?`;
    const wrongs = generateWrongAnswers(x, 3, 1, 4);
    
    return createQuestion(
      text,
      x.toString(),
      wrongs.map(w => w.toString()),
      "fonksiyonlar",
      8,
      2
    );
  } else {
    // Fonksiyon tanimlimi?
    const text = `f = {(1,a), (2,b), (3,c), (1,d)} kumesi bir fonksiyon tanimlar mi?`;
    
    return createQuestion(
      text,
      "Hayir",
      ["Evet", "Belirlenemez", "Bilgi yetersiz"],
      "fonksiyonlar",
      8,
      2
    );
  }
}

// 8. sinif soru uretici haritasi
export const grade8Generators: { [topicId: string]: () => Question } = {
  "uslu-sayilar": generateUsluSayilarQuestion,
  "koklu-sayilar": generateKokluSayilarQuestion,
  "denklem-sistemleri": generateDenklemSistemleriQuestion,
  "esitsizlik-sistemleri": generateEsitsizlikSistemleriQuestion,
  "ucgen-eslik-benzerlik": generateUcgenEslikBenzerlikQuestion,
  "pisagor-teoremi": generatePisagorTeremiQuestion,
  "olasilik-8": generateOlasilik8Question,
  "fonksiyonlar": generateFonksiyonlarQuestion,
};
