// 6. Sinif Soru Ureticileri

import {
  Question,
  randomInt,
  createQuestion,
  generateWrongAnswers,
  simplifyFraction,
  formatNumber,
  formatDecimal,
} from "./generator";

// Tam Sayilar
export function generateTamSayilarQuestion(): Question {
  const type = randomInt(1, 4);
  
  if (type === 1) {
    // Toplama
    const a = randomInt(-50, 50);
    const b = randomInt(-50, 50);
    const result = a + b;
    
    const aStr = a >= 0 ? `(+${a})` : `(${a})`;
    const bStr = b >= 0 ? `(+${b})` : `(${b})`;
    const text = `${aStr} + ${bStr} = ?`;
    
    const wrongs = generateWrongAnswers(result, 3, 1, 20);
    return createQuestion(
      text,
      result.toString(),
      wrongs.map(w => w.toString()),
      "tam-sayilar",
      6,
      1
    );
  } else if (type === 2) {
    // Cikarma
    const a = randomInt(-50, 50);
    const b = randomInt(-50, 50);
    const result = a - b;
    
    const aStr = a >= 0 ? `(+${a})` : `(${a})`;
    const bStr = b >= 0 ? `(+${b})` : `(${b})`;
    const text = `${aStr} - ${bStr} = ?`;
    
    const wrongs = generateWrongAnswers(result, 3, 1, 20);
    return createQuestion(
      text,
      result.toString(),
      wrongs.map(w => w.toString()),
      "tam-sayilar",
      6,
      2
    );
  } else if (type === 3) {
    // Carpma
    const a = randomInt(-12, 12);
    const b = randomInt(-12, 12);
    if (a === 0 || b === 0) return generateTamSayilarQuestion();
    const result = a * b;
    
    const aStr = a >= 0 ? `(+${a})` : `(${a})`;
    const bStr = b >= 0 ? `(+${b})` : `(${b})`;
    const text = `${aStr} x ${bStr} = ?`;
    
    const wrongs = generateWrongAnswers(result, 3, 2, 30);
    return createQuestion(
      text,
      result.toString(),
      wrongs.map(w => w.toString()),
      "tam-sayilar",
      6,
      2
    );
  } else {
    // Mutlak deger
    const a = randomInt(-50, 50);
    const result = Math.abs(a);
    
    const text = `|${a}| = ?`;
    const wrongs = [a, -result, result + randomInt(1, 10)].filter(w => w !== result);
    
    return createQuestion(
      text,
      result.toString(),
      wrongs.slice(0, 3).map(w => w.toString()),
      "tam-sayilar",
      6,
      1
    );
  }
}

// Kesirlerde Islemler
export function generateKesirlerdeIslemlerQuestion(): Question {
  const type = randomInt(1, 2);
  
  if (type === 1) {
    // Kesir carpma
    const num1 = randomInt(1, 5);
    const denom1 = randomInt(2, 8);
    const num2 = randomInt(1, 5);
    const denom2 = randomInt(2, 8);
    
    const resultNum = num1 * num2;
    const resultDenom = denom1 * denom2;
    const [sNum, sDenom] = simplifyFraction(resultNum, resultDenom);
    
    const answer = sDenom === 1 ? `${sNum}` : `${sNum}/${sDenom}`;
    const text = `${num1}/${denom1} x ${num2}/${denom2} = ?`;
    
    const wrongs = [
      `${num1 + num2}/${denom1 + denom2}`,
      `${resultNum + 1}/${resultDenom}`,
      `${Math.max(1, resultNum - 1)}/${resultDenom}`,
    ];
    
    return createQuestion(text, answer, wrongs, "kesirlerde-islemler", 6, 2);
  } else {
    // Kesir bolme
    const num1 = randomInt(1, 6);
    const denom1 = randomInt(2, 6);
    const num2 = randomInt(1, 4);
    const denom2 = randomInt(2, 6);
    
    const resultNum = num1 * denom2;
    const resultDenom = denom1 * num2;
    const [sNum, sDenom] = simplifyFraction(resultNum, resultDenom);
    
    const answer = sDenom === 1 ? `${sNum}` : `${sNum}/${sDenom}`;
    const text = `${num1}/${denom1} / ${num2}/${denom2} = ?`;
    
    const wrongs = [
      `${num1 * num2}/${denom1 * denom2}`,
      `${resultNum + 1}/${resultDenom}`,
      `${resultDenom}/${resultNum}`,
    ];
    
    return createQuestion(text, answer, wrongs, "kesirlerde-islemler", 6, 3);
  }
}

// Oran ve Oranti
export function generateOranOrantiQuestion(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // Basit oran
    const a = randomInt(2, 10);
    const b = randomInt(2, 10);
    const [sA, sB] = simplifyFraction(a, b);
    
    const text = `${a} ile ${b} sayilarinin en sade orani nedir?`;
    const answer = `${sA}/${sB}`;
    
    const wrongs = [
      `${a}/${b}`,
      `${sB}/${sA}`,
      `${sA + 1}/${sB}`,
    ].filter(w => w !== answer);
    
    return createQuestion(text, answer, wrongs.slice(0, 3), "oran-oranti", 6, 1);
  } else if (type === 2) {
    // Oranti cozme
    const a = randomInt(2, 8);
    const b = randomInt(2, 8);
    const c = randomInt(2, 8);
    const result = (b * c) / a;
    
    if (!Number.isInteger(result)) return generateOranOrantiQuestion();
    
    const text = `${a}/${b} = ${c}/x ise x = ?`;
    const wrongs = generateWrongAnswers(result, 3, 1, 5);
    
    return createQuestion(
      text,
      result.toString(),
      wrongs.map(w => w.toString()),
      "oran-oranti",
      6,
      2
    );
  } else {
    // Oranti problemi
    const rate = randomInt(2, 5);
    const quantity1 = randomInt(2, 6);
    const quantity2 = randomInt(7, 12);
    const price1 = rate * quantity1;
    const result = rate * quantity2;
    
    const text = `${quantity1} kalem ${price1} TL ise, ${quantity2} kalem kac TL dir?`;
    const wrongs = generateWrongAnswers(result, 3, 2, 10);
    
    return createQuestion(
      text,
      `${result} TL`,
      wrongs.map(w => `${w} TL`),
      "oran-oranti",
      6,
      2
    );
  }
}

// Cebire Giris
export function generateCebireGirisQuestion(): Question {
  const type = randomInt(1, 3);
  
  if (type === 1) {
    // ax + b = c
    const a = randomInt(2, 6);
    const x = randomInt(1, 10);
    const b = randomInt(1, 10);
    const c = a * x + b;
    
    const text = `${a}x + ${b} = ${c} ise x = ?`;
    const wrongs = generateWrongAnswers(x, 3, 1, 5);
    
    return createQuestion(
      text,
      x.toString(),
      wrongs.map(w => w.toString()),
      "cebire-giris",
      6,
      2
    );
  } else if (type === 2) {
    // ax - b = c
    const a = randomInt(2, 6);
    const x = randomInt(3, 12);
    const b = randomInt(1, a * x - 1);
    const c = a * x - b;
    
    const text = `${a}x - ${b} = ${c} ise x = ?`;
    const wrongs = generateWrongAnswers(x, 3, 1, 5);
    
    return createQuestion(
      text,
      x.toString(),
      wrongs.map(w => w.toString()),
      "cebire-giris",
      6,
      2
    );
  } else {
    // Degisken yerine koyma
    const x = randomInt(2, 8);
    const a = randomInt(2, 5);
    const b = randomInt(1, 10);
    const result = a * x + b;
    
    const text = `x = ${x} ise, ${a}x + ${b} ifadesinin degeri kactir?`;
    const wrongs = generateWrongAnswers(result, 3, 2, 10);
    
    return createQuestion(
      text,
      result.toString(),
      wrongs.map(w => w.toString()),
      "cebire-giris",
      6,
      1
    );
  }
}

// Daire
export function generateDaireQuestion(): Question {
  const type = randomInt(1, 2);
  const r = randomInt(2, 10);
  
  if (type === 1) {
    // Daire cevresi
    const result = 2 * Math.PI * r;
    const text = `Yaricapi ${r} cm olan dairenin cevresi kac cm dir? (pi = 3,14)`;
    const approxResult = +(2 * 3.14 * r).toFixed(2);
    
    const wrongs = [
      formatDecimal(approxResult + 3.14),
      formatDecimal(approxResult - 3.14),
      formatDecimal(3.14 * r * r),
    ];
    
    return createQuestion(
      text,
      formatDecimal(approxResult),
      wrongs,
      "daire",
      6,
      2
    );
  } else {
    // Daire alani
    const result = Math.PI * r * r;
    const text = `Yaricapi ${r} cm olan dairenin alani kac cm² dir? (pi = 3,14)`;
    const approxResult = +(3.14 * r * r).toFixed(2);
    
    const wrongs = [
      formatDecimal(2 * 3.14 * r),
      formatDecimal(approxResult + 10),
      formatDecimal(Math.max(1, approxResult - 10)),
    ];
    
    return createQuestion(
      text,
      formatDecimal(approxResult),
      wrongs,
      "daire",
      6,
      2
    );
  }
}

// Veri Analizi
export function generateVeriAnaliziQuestion(): Question {
  const type = randomInt(1, 3);
  
  // 5 sayidan olusan veri seti
  const data = Array.from({ length: 5 }, () => randomInt(10, 50));
  const sorted = [...data].sort((a, b) => a - b);
  
  if (type === 1) {
    // Ortalama
    const sum = data.reduce((a, b) => a + b, 0);
    const result = sum / data.length;
    
    const text = `${data.join(", ")} sayilarinin aritmetik ortalamasi kactir?`;
    const wrongs = generateWrongAnswers(result, 3, 2, 8);
    
    return createQuestion(
      text,
      Number.isInteger(result) ? result.toString() : formatDecimal(result, 1),
      wrongs.map(w => Number.isInteger(w) ? w.toString() : formatDecimal(w, 1)),
      "veri-analizi",
      6,
      2
    );
  } else if (type === 2) {
    // Ortanca (medyan)
    const result = sorted[2]; // 5 elemanli dizide ortanca 3. eleman
    
    const text = `${data.join(", ")} sayilarinin ortancasi (medyani) kactir?`;
    const wrongs = [sorted[0], sorted[4], sorted[1]].filter(w => w !== result);
    
    return createQuestion(
      text,
      result.toString(),
      wrongs.slice(0, 3).map(w => w.toString()),
      "veri-analizi",
      6,
      2
    );
  } else {
    // Mod (tekrarli veri olustur)
    const modeValue = randomInt(10, 40);
    const dataWithMode = [modeValue, modeValue, randomInt(10, 50), randomInt(10, 50), randomInt(10, 50)];
    
    const text = `${dataWithMode.join(", ")} sayilarinin modu kactir?`;
    const wrongs = dataWithMode.filter(d => d !== modeValue).slice(0, 3);
    
    return createQuestion(
      text,
      modeValue.toString(),
      wrongs.map(w => w.toString()),
      "veri-analizi",
      6,
      1
    );
  }
}

// 6. sinif soru uretici haritasi
export const grade6Generators: { [topicId: string]: () => Question } = {
  "tam-sayilar": generateTamSayilarQuestion,
  "kesirlerde-islemler": generateKesirlerdeIslemlerQuestion,
  "oran-oranti": generateOranOrantiQuestion,
  "cebire-giris": generateCebireGirisQuestion,
  "daire": generateDaireQuestion,
  "veri-analizi": generateVeriAnaliziQuestion,
};
