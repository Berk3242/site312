"use client";

import { useEffect } from "react";
import confetti from "canvas-confetti";

export function triggerConfetti(type: "success" | "levelUp" | "badge" | "boss") {
  const defaults = {
    origin: { y: 0.7 },
    zIndex: 9999,
  };

  switch (type) {
    case "success":
      confetti({
        ...defaults,
        particleCount: 50,
        spread: 60,
        colors: ["#10b981", "#34d399", "#6ee7b7"],
      });
      break;

    case "levelUp":
      const duration = 2000;
      const end = Date.now() + duration;

      const frame = () => {
        confetti({
          particleCount: 3,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: ["#fbbf24", "#f59e0b", "#d97706"],
          zIndex: 9999,
        });
        confetti({
          particleCount: 3,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: ["#fbbf24", "#f59e0b", "#d97706"],
          zIndex: 9999,
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };
      frame();
      break;

    case "badge":
      confetti({
        ...defaults,
        particleCount: 100,
        spread: 100,
        colors: ["#8b5cf6", "#a78bfa", "#c4b5fd", "#fbbf24", "#f59e0b"],
      });
      break;

    case "boss":
      const bossDuration = 3000;
      const bossEnd = Date.now() + bossDuration;

      const bossFrame = () => {
        confetti({
          particleCount: 5,
          angle: 60,
          spread: 80,
          origin: { x: 0, y: 0.6 },
          colors: ["#ef4444", "#f97316", "#fbbf24", "#eab308"],
          zIndex: 9999,
        });
        confetti({
          particleCount: 5,
          angle: 120,
          spread: 80,
          origin: { x: 1, y: 0.6 },
          colors: ["#ef4444", "#f97316", "#fbbf24", "#eab308"],
          zIndex: 9999,
        });

        if (Date.now() < bossEnd) {
          requestAnimationFrame(bossFrame);
        }
      };
      bossFrame();
      break;
  }
}

export function ConfettiEffect({ trigger, type }: { trigger: boolean; type: "success" | "levelUp" | "badge" | "boss" }) {
  useEffect(() => {
    if (trigger) {
      triggerConfetti(type);
    }
  }, [trigger, type]);

  return null;
}
